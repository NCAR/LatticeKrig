# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig <- function(x,   y = NULL,
                 weights = rep(1, nrow(x)),
                       Z = NULL,
                  LKinfo = NULL, 
                   iseed = 123, 
	                NtrA = 20, 
            use.cholesky = NULL,
         return.cholesky = TRUE,
          choleskyMemory = NULL,
                	   X = NULL, 
                	   U = NULL,
                	  wX = NULL,
                	  wU = NULL,
          return.wXandwU = TRUE,
               	            ...,
               	 verbose = FALSE) {
	# make sure locations are a matrix and get the rows
	x <- as.matrix(x)
	y <- as.matrix(y)
	n <- nrow(x)
	if (any(duplicated(cat.matrix(x)))) 
		stop("locations are not unique see help(LKrig) ")
	# make sure covariate is a matrix
	if (!is.null(Z)) {
		Z <- as.matrix(Z)
	}
	# check for missing values
	if (!is.null(y)) {
		if (any(is.na(y))) 
			stop("Missing values in y not allowed ")
	}

	# if LKinfo is missing create it from passed arguments   
	if (is.null(LKinfo)) {
		LKinfo <- do.call("LKrigSetup", c(list(x = x), list(...),
		 list(verbose = verbose)))
	}

	#   At this point the LKinfo object should have the right lambda value. 
	lambda = LKinfo$lambda
	if (is.na(lambda)) {
		stop("lambda must be specified")
	}
	#   Use memory estimate from LKinfo if available
	#   NOTE: this value might be NULL in LKinfo
    if (is.null(choleskyMemory)) {
		choleskyMemory <- LKinfo$choleskyMemory
	}
	if( verbose & !is.null(choleskyMemory) ){		
	 cat( "choleskyMemory: ", choleskyMemory, fill=TRUE )
	}
	# Begin computations ....
	# weighted observation vector
    wy <- sqrt(weights) * y
	# Spatial drift matrix -- default is assumed to be linear in coordinates (m=2)
	# and includes possible covariate(s) -- the Z matrix.
    # the choice of fixed part of the model is controlled in LKrigSetup
    #
    # Code should work without including a wU component i.e. there is no fixed part
    # just the spatial component based on the LatticeKrig covariance.

if (is.null(wU)) {
	if( !is.null(U)){
		wU <- sqrt(weights) * U
	} else {
		if (!is.null(LKinfo$fixedFunction)) {
			wU <- sqrt(weights) * do.call(LKinfo$fixedFunction,
			                c(list(x = x, Z = Z, distance.type = LKinfo$distance.type), 
				            LKinfo$fixedFunctionArgs))			
		} 
	}	
	}
if( verbose){
	print("dim wU")
	print( dim(wU))
}	
if( is.null(wU)){
			nt <- 0
			ind.drift <- NULL
			nZ <- 0
} else {
			nt <- ncol(wU)
			nZ <- ifelse(is.null(Z), 0, ncol(Z))
			ind.drift <- c(rep(TRUE, (nt - nZ)), rep(FALSE, nZ))
}
#  wX is the matrix of sum( N1*N2) basis function (columns) evaluated at the N locations (rows)
# and multiplied by square root of diagonal weight matrix
# this can be a large matrix if not encoded in sparse format.
timewX<- system.time(
if (is.null(wX)) {
	if( !is.null(X)){
    	wX<- diag.spam(sqrt(weights)) %*% X	
	} else {
		wX <- diag.spam(sqrt(weights)) %*% LKrig.basis(x, LKinfo,
		                  verbose = verbose)		
	}
	}
	)
	if( verbose){
		print("dim wX")
		print( dim( wX))
	}
	#   square root of precision matrix of the lattice process
	#   solve(t(H)%*%H) is proportional to the covariance matrix of the Markov Random Field
timeQ<-system.time(
        Q <- LKrig.precision(LKinfo, verbose=verbose)
        )
	# M is the regularized regression matrix that is the key to the entire algorithm:
timeM<- system.time(	
	M <- t(wX) %*% wX + lambda * (Q)
	)
	nzero <- length(M@entries)
	if( verbose){
		print("nozero")
		print( nzero)
	}
	# find Cholesky square root of M
	#  This is where the heavy lifting happens!  M is in sparse format so
#   by the overloading is a sparse cholesky decomposition.
#  if this function has been coded efficiently this step should dominate
#  all other computations.
#  If  a previous sparse cholesky decoposition is passed then the
#  pattern of sparseness is used for the decoposition.
#  This can speed the computation as the symbolic decomposition part of the
#  sparse Cholesky is a nontrivial step. The condition is that
#  the current 'M' matrix  has the same sparse pattern as that
#  which resulted in the factorization  cholesky as 'use.cholesky'
if (is.null(use.cholesky)) {
	timeChol<- system.time(
		Mc <- chol(M, memory = choleskyMemory)
		)
	} else {	
			timeChol<- system.time(
		Mc <- update.spam.chol.NgPeyton(use.cholesky, M)
		)
	}

	# partially fill object list with some components
	object <- list(x = x, y = y, weights = weights, Z = Z, nZ = nZ,
	         ind.drift = ind.drift, 
		LKinfo = LKinfo, lambda = lambda)
	# use Mc to find coefficients of estimate
	timeCoef<- system.time(
	out1 <- LKrig.coef(Mc, wX, wU, wy, lambda, weights)
	)
	if (verbose) {
		cat(" d.coef", out1$d.coef, fill = TRUE)
	}
	# add in components from coefficient estimates
	object <- c(object, out1)
	# compute predicted values    
	fitted.values <- (wX %*% out1$c.coef)/sqrt(weights)
	if (!is.null(LKinfo$fixedFunction) | !is.null(wU)) {
		fitted.values.fixed <- (wU %*% out1$d.coef)/sqrt(weights)
		fitted.values <- fitted.values.fixed + fitted.values
	}
	# For reference: fitted.values <- predict.LKrig(object, x, Znew = object$Z)
	residuals <- y - fitted.values
# find likelihood
timeLike<- system.time(	
	out2 <- LKrig.lnPlike(Mc, Q, y, lambda, residuals, weights, LKinfo$sigma,
	   LKinfo$rho, choleskyMemory = choleskyMemory)
	   )
	object <- c(object, out2)
# estimate trace of hat matrix (effective degrees of freedom)
# by Monte Carlo if NtrA greater than zero
timeTrA<- system.time(
	if (NtrA > 0) {
		out3 <- LKrig.traceA(Mc, wX, wU, lambda, weights, NtrA, iseed)
		# find GCV using this trace estimate
		out3$GCV = (sum(weights * (residuals)^2)/n)/(1 - out3$trA.est/n)^2
	} else {
		out3 <- list(trA.est = NA, trA.SE = NA, GCV = NA)
	}
	)
	object <- c(object, out3)
# the output object
# note the ifelse switch whether to return the big cholesky decomposition
# and/or the weighted basis matrix wX
timingTable<- rbind(timewX, timeQ, timeM, timeChol, timeCoef, timeLike,  timeTrA)
timingTable<- timingTable[,1:3]
timingTable <- rbind( timingTable, colSums(timingTable))

object <- c(object, list(fitted.values = fitted.values, residuals = residuals, 
   lambda.fixed = lambda, nonzero.entries = nzero, nt = nt,
   eff.df = out3$trA.est, call = match.call(), 
   timingLKrig=timingTable )
    )
	if (return.cholesky) {
		object$Mc <- Mc
	}
	if (return.wXandwU) {
		object$X <- wX
		object$U <- wU
	}
	# set the class and return.
	class(object) <- "LKrig"
	return(object)
}

