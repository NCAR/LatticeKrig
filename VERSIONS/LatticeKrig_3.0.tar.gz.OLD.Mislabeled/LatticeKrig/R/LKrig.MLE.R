LKrig.MLE <- function(x, y, ..., LKinfo, par.grid = NULL, 
    lambda.profile = TRUE, verbose = FALSE, lowerBoundLogLambda=-16) {
    LKrig.args <- c(list(x = x, y = y), list(...))
    # at this point LKinfo has the correct value for the number of multiresolution levels
    par.grid <- LKrig.make.par.grid(par.grid = par.grid, LKinfo = LKinfo)
  #  if (verbose) {
  #     print(par.grid)
  #  }
    # output matrix
    NG <- length(par.grid$alpha)
    if (verbose) {
        print(NG)
    }
    if (length(par.grid$llambda) != NG) {
        stop("llambda values not same length as alpha")
    }
    if (length(par.grid$a.wght) != NG) {
        stop("a.wght values not same length as alpha")
    }
    out <- matrix(NA, nrow = NG, ncol = 9)
    optim.counts <- rep(NA, 2)
    dimnames(out) <- list(NULL, c("EffDf", "lnProfLike", "GCV", 
        "sigma.MLE", "rho.MLE", "llambda.MLE", "lnLike", "counts value", 
        "grad"))
    #  temporary function used in optimizer
    temp.fn <- function(x) {
# if( x< lowerBoundLogLambda){
#             warning( "value of lambda below 1e-7")
#              lnLike<- 1e10}
# else{
        lnLike <- do.call("LKrig", c(LKrig.args, list(LKinfo = LKinfo.temp, 
            lambda = exp(x), use.cholesky = MC.save, NtrA = 0)))$lnProfileLike.FULL
#      }
        lnLike
    }
    # first fit to get cholesky symbolic decomposition
    LKinfo.temp<- LKinfoUpdate( LKinfo, a.wght = (par.grid$a.wght[[1]]),
                                         alpha =  (par.grid$alpha[[1]]),
                                            nu = par.grid$nu[1] )
    # save decomp
    MC.save <- do.call("LKrig", c(LKrig.args, list(LKinfo = LKinfo.temp, 
        lambda = 1, NtrA = 0)))$MC
    # evaluate parameters but do an optimzation over lambda
    lnProfileLike.max <- -1e+20
    for (k in 1:NG) {
        llambda.start <- par.grid$llambda[k]
        # if starting value is missing use the optimum from previous fit
        # this only really makes sense if other parameters have some sort of continuity from k-1 to k.
        if (is.na(llambda.start) & (k != 1)) {
            llambda.start <- llambda.opt
        }
        # Note each component of alpha and a.wght is also a list!
# OLD code:        
#         LKinfoTempCall <- LKinfo$call
#         LKinfoTempCall$a.wght <- (par.grid$a.wght[[k]])
#         LKinfoTempCall$alpha <- (par.grid$alpha[[k]])
#         LKinfoTempCall$nu <- par.grid$nu[k]
#         LKinfo.temp<- eval( LKinfoTempCall)
         LKinfo.temp<- LKinfoUpdate( LKinfo, a.wght= (par.grid$a.wght[[k]]),
                                             alpha =  (par.grid$alpha[[k]]),
                                             nu= par.grid$nu[k] )
        #    if( verbose){
        #      print( LKinfo.temp)}
        if (lambda.profile) {
        # the try wrapper captures case when optim fails.   
             look<-try( optim(llambda.start, temp.fn, method = "BFGS", 
                           control = list(fnscale = -1, parscale = 0.2, 
                           ndeps = 0.01, reltol = 1e-06)),
                   silent=FALSE )
             evalSummary <- !(class( look)== "try-error")
             llambda.opt <- look$par
             optim.counts <- look$counts
        }
        else {
            llambda.opt <- llambda.start
            evalSummary<- TRUE
        }
        if( evalSummary){
          obj <- do.call("LKrig", c(LKrig.args, list(LKinfo = LKinfo.temp, 
              lambda = exp(llambda.opt), use.cholesky = MC.save, 
              NtrA = 20)))
        # compare to current largest likelihood and update the LKinfo list if bigger.
          if (obj$lnProfileLike.FULL > lnProfileLike.max) {
              lnProfileLike.max <- obj$lnProfileLike.FULL
              LKinfo.MLE <- obj$LKinfo
          }
        # save summary results from this set of parameters.
          out[k, 1] <- obj$trA.est
          out[k, 2] <- obj$lnProfileLike.FULL
          out[k, 3] <- obj$GCV
          out[k, 4] <- obj$sigma.MLE.FULL
          out[k, 5] <- obj$rho.MLE.FULL
          out[k, 6] <- llambda.opt
          out[k, 7] <- obj$lnLike.FULL
          out[k, 8:9] <- optim.counts
        }
        if (verbose) {
            cat("  ", k, "eff.df:", out[k, 1], "lnProfileLike:", 
                out[k, 2],"llambda.start:", llambda.start, "logLambda:", out[k, 6], "lnLike:", 
                out[k, 7],"optimCounts:", out[k, 8:9],  fill = TRUE)
        }
    }
    return(list(summary = out, par.grid = par.grid, LKinfo = LKinfo, 
        LKinfo.MLE = LKinfo.MLE, call = match.call()))
}

