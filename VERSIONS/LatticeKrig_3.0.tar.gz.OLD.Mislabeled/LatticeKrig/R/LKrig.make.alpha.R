LKrig.make.alpha<- function( alpha, nu, nlevel){
  # determine alpha if nu has been specified
    scalar.alpha <- !is.list(alpha) | !is.null(nu)
    if (!is.null(nu)) {
        alpha <- exp(-2 * (1:nlevel) * nu)
        alpha <- alpha/sum(alpha)
    }
    if (scalar.alpha & (nlevel != 1) & (length(alpha) == 1)){
                stop( "Only one alpha specifed for multiple levels")}     
# coerce alpha to a list if it is passed as something else
    if (!is.list(alpha)) {
        alpha <- as.list(alpha)
    }
    return( list( alpha=alpha, scalar.alpha= scalar.alpha))
    
  }
