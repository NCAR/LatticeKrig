LKrig.make.par.grid <-
function (par.grid = NULL, llambda = NULL, LKinfo = NULL) 
{
    if (is.null(par.grid)) {
      # special case of just search over lambda
        if (is.null(llambda)) {
            stop("Need to specify llambda grid")
        }
        par.grid <- list(llambda = as.matrix(llambda))
        NG <- length(par.grid$llambda)
        par.grid$alpha <- matrix(LKinfo$alpha, nrow = NG, ncol = LKinfo$nlevel, 
            byrow = TRUE)
        par.grid$a.wght <- matrix(LKinfo$a.wght, nrow = NG, ncol = LKinfo$nlevel, 
            byrow = TRUE)
        par.grid$gamma <- matrix(NA, ncol=LKinfo$nlevel, nrow=1)
        par.grid$lkappa <- NA
    }
    else {
        par.grid$llambda <- as.matrix(par.grid$llambda)
        if (!is.null(par.grid$gamma)) {
      
            par.grid$alpha <- cbind(1, exp(par.grid$gamma))
            for (j in 1:nrow(par.grid$gamma)) {
                par.grid$alpha[j, ] <- par.grid$alpha[j, ]/sum(par.grid$alpha[j, 
                  ])
            }
        }
        nlevel <- ncol(par.grid$alpha)
        if (!is.null(par.grid$lkappa)) {
        # coerce to lkappa to a matrix  
            par.grid$lkappa<- as.matrix(par.grid$lkappa)
            par.grid$a.wght <- as.matrix(4 + 1/(exp(par.grid$lkappa)^2))
    
            par.grid$a.wght <- rep.matrix(par.grid$a.wght, nlevel, 
                byrow = FALSE)
 
        }
    }
    return(par.grid)
}
