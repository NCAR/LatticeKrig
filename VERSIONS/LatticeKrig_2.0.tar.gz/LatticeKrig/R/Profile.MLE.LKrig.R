Profile.MLE.LKrig<- function( obj, plevel=.95){
  LKinfo<- obj$MR.MLE$LKinfo.MLE
  X.temp<- obj$X.temp
  Y.temp<- obj$Y.temp
  nlevel<- LKinfo$nlevel
  mX<- nrow( X.temp)
  nX<- ncol( X.temp)
  nlkappa<- nX - (nlevel -1) -1
  
 
  
  obj.like<- Tps( X.temp, Y.temp, m=3, lambda=0)
    X.temp.range<- apply( X.temp,2, "range")
    x.scale<-  c((X.temp.range[2,] -  X.temp.range[1,])/2)
    x.center<- rbind(X.temp[which.max(Y.temp), ])
  out<-out2 <- rep( NA, nX)
  
  temp.fn<-  function(x){predict( obj.like,rbind(c(gamma.lkappa.temp,x)))}
  llambda.scale<-  max(X.temp[,nX]) - min(X.temp[,nX])
  for ( k in 1: mX){
      gamma.lkappa.temp<- X.temp[k,-nX]
      llambda.start<- X.temp[k,nX]     
      look<- optim( llambda.start, temp.fn,
                     method="BFGS", control=list(fnscale=-1, parscale=llambda.scale*.05))
      out[k] <- look$value
      out2[k]<- look$par
      cat( k, look$par,look$value, Y.temp[k], fill=TRUE)
    }
  llambda.est<- out2
  look<- LKrig.cov.plot(LKinfo)
  x.dist<- look$d
  temp1<-temp2<- matrix( NA,nrow=nrow( x.dist), ncol= mX)
   ind <- ifelse( plevel ==1, rep( TRUE,nX), out  >= max( out) -  qchisq( plevel,nX-1)/2)
   cat( "number of points in CI", sum( ind), fill=TRUE)
   par.grid.matrix<-  cbind( X.temp[,-nX], llambda.est)
   par.grid<- LKrig.make.par.grid( par.grid.matrix= par.grid.matrix, LKinfo=LKinfo)
  for( k in 1: mX){
 
        cat(k," ")
        LKinfo.temp<-LKinfo
        LKinfo.temp$alpha<- par.grid$alpha[k,]
        LKinfo.temp$a.wght<-  par.grid$a.wght[k,]
        hold<-  LKrig.cov.plot( LKinfo.temp)
        temp1[,k] <- hold$cov[,1]
        temp2[,k] <- hold$cov[,2]
    
  }  
 return( list( X.temp=X.temp, Y.temp=Y.temp, lnProfileLike=out, d= x.dist, cov1= temp1, cov2=temp2, ind=ind, par.grid.matrix=par.grid.matrix, LKinfo=LKinfo))
}
