# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2


setDefaultsLKinfo.LKRectangle <- function(object,...)
  {
  	if( is.na(object$basisInfo$V)){
  		object$basisInfo$V <- diag( rep(1,2))
  	}
    return(object)
  }
  
LKrigSetupLattice.LKRectangle <- function(object, x, verbose,                                         
                                          NC=NULL, NC.buffer=5, grid.info=NULL,
                                          ... ){
###### some common setup opertations to all geometries
  LKinfo<- object
  if(  class( LKinfo)[1] != "LKinfo") {
    stop("object needs to an LKinfo object")
  }
  rangeLocations<- apply( x,2, "range")
  nlevel<- LKinfo$nlevel
###### end common operations  
  
   if (is.null(NC)) {
      stop("Need to specify NC for grid size")
        }
#  if ( LKinfo$distance.type!= "Euclidean" ) {
#        stop("distance type is not supported (or is misspelled!).")        
#     }
# if lattice information is missing create grid based on the locations
   if (is.null(grid.info)) {
        # find range of scaled locations
        range.x <- apply(as.matrix(x) %*% t(solve(LKinfo$basisInfo$V)),
                               2, "range")
        if (verbose) {
            cat("ranges of transformed variables", range.x, fill = TRUE)
        }
        grid.info <- list(xmin = range.x[1, 1], xmax = range.x[2, 
            1], ymin = range.x[1, 2], ymax = range.x[2, 2])
    }
# set the largest spacing of centers if not given in grid.info    
    if( is.null(grid.info$delta)){        
        d1 <- grid.info$xmax - grid.info$xmin
        d2 <- grid.info$ymax - grid.info$ymin
        grid.info$delta <-  max(c(d1, d2))/(NC - 1)
    }
    #
    # actual number of grid points is determined by the spacing delta
    # delta is used so that centers are equally
    # spaced in both axes and NC is the maximum number of grid points
    # along the larger range. So for a rectangular region
    # along the longer side there will be NC grid points but for the shorter dimension
    # there will be less than NC.
    # Finally note that if NC.buffer is greater than zero the number of grid points in
    # both dimensions will be increased by this buffer around the edges:
    # A total of  NC + 2* NC.buffer grid points along the longer dimension
    #
    delta.level1 <- grid.info$delta
    delta.save <- mx <- my <- rep(NA, nlevel)
    #
    # build up series of nlevel multi-resolution grids
    # and accumulate these in a master list -- creatively called grid
    grid.all.levels <- NULL
    # loop through multiresolution levels decreasing delta by factor of 2
    # and compute number of grid points.
    # build in a hook for buffer regions to differ in x and y
    NC.buffer.x <- NC.buffer
    NC.buffer.y <- NC.buffer
    for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width.x <- NC.buffer.x * delta
        buffer.width.y <- NC.buffer.y * delta 
        # rectangular case
        grid.list <- list(x = seq(grid.info$xmin - buffer.width.x, 
            grid.info$xmax + buffer.width.x, delta), y = seq(grid.info$ymin - 
            buffer.width.y, grid.info$ymax + buffer.width.y, 
            delta))
        mx[j] <- length(grid.list$x)
        my[j] <- length(grid.list$y)
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
    # end multiresolution level loop
    # create a useful index that indicates where each level starts in a
    # stacked vector of the basis function coefficients.
    mLevel<- mx*my
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (mx - 2 * NC.buffer.x) * (my - 2 * NC.buffer.y)
  # first five components are used in the print function and
  # should always be created.
  # The remaining compoents are specific to this geometry.
    out<-  list(  m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
  # specific arguments for LKrectangle              
                  mLevelDomain = mLevelDomain,
                  mx = mx, my = my, 
                  NC.buffer.x = NC.buffer.x, NC.buffer.y = NC.buffer.y,  
                  grid = grid.all.levels, grid.info=grid.info
                 )

 return( out ) 
  }  
  

LKrigSetupAlpha.LKRectangle <- function( object, ... ){
   alpha <- object$alpha
   nlevel <- object$nlevel
   nu<- object$nu
   if( is.na(alpha[1]) ) {
        alpha<- rep( NA, nlevel)
    }
    scalar.alpha <- !is.list(alpha) | !is.null(nu)
# determine alpha if nu has been specified
    if (!is.null(nu)) {
        alpha <- exp(-2 * (1:nlevel) * nu)
        alpha <- alpha/sum(alpha)
    }
    if (scalar.alpha & (nlevel != 1) & (length(alpha) == 1)){
                stop( "Only one alpha specifed for multiple levels")}     
# coerce alpha to a list if it is passed as something else
    if (!is.list(alpha)) {
        alpha <- as.list(alpha)
    }
    return( alpha )
  }
  
LKrigSetupAwght.LKRectangle <- function( object, ... ){ 
# the object here should be of class LKinfo	
  a.wght<- object$a.wght
  nlevel<- object$nlevel
  mx<- object$latticeInfo$mx
  my<- object$latticeInfo$my
  if (!is.list(a.wght)) {
        # some checks on a.wght
        # coerce a.wght to list if it is passed as something
        # else (most likely a vector)
        if (nlevel == 1) {
            a.wght <- list(a.wght)
        }
        else {
            # repeat a.wght to fill out for all levels.
            if (length(a.wght) == 1) {
                a.wght <- rep(a.wght, nlevel)
            }
            a.wght <- as.list(c(a.wght))
        }
    }
   # check length of a.wght list
    if (length(a.wght) != nlevel) {
        stop("length of a.wght list differs than of nlevel")
    }
    #################################
    # rest of function determines the type of model
    # setting logicals for stationary, first.order and
    # fastnormalization
    #
    # now figure out if the model is stationary
    # i.e. a.wght pattern is to be  repeated for each node
    # at a given level this is the usual case
    # if not stationary a.wght should be a list of arrays that
    # give values for each node separately
    stationary <- is.null(dim(a.wght[[1]]))
    first.order<- rep( NA, nlevel)
    # simple check on sizes of arrays
    if (stationary) {      
        for (k in 1:length(a.wght)) {
             N.a.wght <- length(a.wght[[1]])
        # allowed lengths for a.wght are just the center 1 values
        # or 9 values for center,  first, and second order neighbors
         if (is.na(match(N.a.wght, c(1, 9)))) {
               stop("a.wght needs to be of length 1 or 9")
        }
           first.order[k]<- ifelse( N.a.wght == 1, TRUE, FALSE)
        }
    }
    else {
        for (k in 1:length(a.wght)) {
            dim.a.wght <- dim(a.wght[[k]])
            if( (dim.a.wght[1] != mx[k]) | (dim.a.wght[2] != my[k]) ) {
                stop(paste(
                    "a.wght matrix at level ", k,
                    " has wrong first two dimensions:", dim.a.wght,
                    " compare to lattice ", mx[k], my[k] ) )
            }
        first.order[k] <- length( dim.a.wght) == 2
        }
     }  
#   
    RBF<- object$basisInfo$RadialBasisFunction 
    fastNormalization <- stationary & 
            all( first.order ) & all( !is.na( unlist( a.wght) ) ) &
             (RBF=="WendlandFunction") 
#NOTE current code is hard wired for Wendland 2 2 RBF  
    if(fastNormalization){
        attr( a.wght, which="fastNormDecomp")<-
           LKRectangleSetupNormalization( mx, my, a.wght)
           }
 # 
    attr( a.wght, which="fastNormalize") <- fastNormalization 
    attr( a.wght, which="first.order") <- first.order
    attr( a.wght, which="stationary") <- stationary
#
  return(a.wght)
  }
     
LKRectangleSetupNormalization<- function(mx,my, a.wght){
  out<- list()
  nlevel<- length( a.wght)
# coerce a.wght from a list with scalar components back to a vector
  a.wght<- unlist( a.wght)
   
  for ( l in 1:nlevel){	
  	  mxl<- mx[l]
   myl<- my[l]
  Ax<- diag( a.wght[l]/2, mxl)
  Ax[  cbind( 2:mxl, 1:(mxl-1)) ] <- -1
  Ax[  cbind( 1:(mxl-1), 2:mxl) ] <- -1
# 
  Ay<- diag( a.wght[l]/2, myl)
  Ay[  cbind( 2:myl, 1:(myl-1)) ] <- -1
  Ay[  cbind( 1:(myl-1), 2:myl) ] <- -1
  eigen( Ax, symmetric=TRUE) -> hold
  Ux<- hold$vectors
  Dx<- hold$values
  eigen( Ay, symmetric=TRUE) -> hold
  Uy<- hold$vectors
  Dy<- hold$values
 # extra list makes out a list where each component is itself a list  
  out<- c(out, list( list( Ux=Ux, Uy=Uy, Dx=Dx, Dy=Dy ) ) )
  }
  return(out)
 }

