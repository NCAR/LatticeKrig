#include <stdio.h>
int main()
{
    printf( "I am alive!  Beware.\n" );
    getchar();
    return 0;
}
