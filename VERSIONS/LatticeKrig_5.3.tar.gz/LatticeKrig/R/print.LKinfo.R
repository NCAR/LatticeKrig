print.LKinfo <- function(x, ...) {
    LKinfo <- x
    L <- LKinfo$nlevel
    cat("Classes for this object are: " , class( LKinfo), fill=TRUE)
    cat("Ranges of locations in raw scale:", fill=TRUE)
    print(  LKinfo$latticeInfo$rangeLocations)
    cat(" ", fill = TRUE)
    cat("Number of levels:", L, fill = TRUE)
    cat("delta scalings:", x$latticeInfo$delta, fill = TRUE)
    cat("with an overlap parameter of ", LKinfo$basisInfo$overlap, fill=TRUE)
    cat("alpha: ", unlist(x$alpha), fill = TRUE)
    if (!is.null(x$nu)) {
        cat("based on smoothness nu = ", x$nu, fill = TRUE)
    }
    cat("a.wght: ", unlist(x$a.wght), fill = TRUE)
       cat(" ", fill = TRUE)
    cat("Distance type: ", LKinfo$distance.type, fill = TRUE)
        cat(" ", fill = TRUE)
      temp<- cbind( 1:L, LKinfo$latticeInfo$mLevel)
      dimnames( temp)<- list( rep( "", L), c("Level" ,   "Basis size"))
      print( temp)
      cat("Total basis functions ",  LKinfo$latticeInfo$m, fill=TRUE)
# Details on basis functions at each level
      bType <- LKinfo$basisInfo$BasisType
      cat( "Basis  type:", bType, fill=TRUE)
      cat( "Basis function:",
           LKinfo$basisInfo$BasisFunction, fill=TRUE)
        if( LKinfo$normalize){
        cat("Basis functions will be normalized to approximate stationarity", fill=TRUE)
        }
        cat(" ", fill = TRUE)   
}



