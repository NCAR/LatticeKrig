directionCosines<- function( x){
# x is lon/lat in degrees
# x[,3] if there is the radial component
     coslat <- cos((x[, 2] * pi)/180)
     sinlat <- sin((x[, 2] * pi)/180)
     coslon <- cos((x[, 1] * pi)/180)
     sinlon <- sin((x[, 1] * pi)/180)
# if just 2 d then assume the points are on sphere
# if dim >= 3 then include the radial component.
if( ncol(x)==2){
return( cbind(coslon*coslat, sinlon*coslat, sinlat))
}
else{
	return( x[,3]*cbind(coslon*coslat, sinlon*coslat, sinlat))
}
}