timeLKrig<- function(N, NC=10, nlevel=4, normalize=TRUE, seed=123){
	   set.seed(seed)
	   x<- matrix( runif(2*N),N,2)	
	   y<- rnorm(N)
	   LKinfo <- LKrigSetup( rbind(c(0,0),c(1,1)), NC=NC, nlevel=nlevel,
	   nu=1.0, normalize=normalize, a.wght=5, lambda= 1.0)
	   time.out<- system.time( obj<- LKrig( x, y, LKinfo=LKinfo))
	   return( rbind(time.out, obj$timeLKrig))
	}
timeLKrig.basis<- function(N, NC=10, nlevel=4, normalize=TRUE, seed=123){
	   set.seed(seed)
	   x<- matrix( runif(2*N),N,2)	
	   y<- rnorm(N)
	   LKinfo <- LKrigSetup( rbind(c(0,0),c(1,1)), NC=NC, nlevel=nlevel,
	   nu=1.0, normalize=normalize, a.wght=5, lambda= 1.0)
	   time.out<- system.time( obj<- LKrig.basis( x,  LKinfo=LKinfo, verbose=TRUE))
	   return( rbind(time.out))
	}