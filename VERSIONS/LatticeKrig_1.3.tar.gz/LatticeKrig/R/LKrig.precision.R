LKrig.precision <-
function( LKinfo, return.B=FALSE, level.index=NA)
{
   mx<- LKinfo$mx
   my<- LKinfo$my
   grid.info<- LKinfo$grid.info
   L<- LKinfo$nlevel
   if(L!= length(my)){
     stop("number of levels and mx and my are not consistent")}
   offset<- LKinfo$offset
   alpha<- LKinfo$alpha
   a.wght<- LKinfo$a.wght
# some checks on arguments
   if((length(alpha)!= L) |
      (length(a.wght)!= L)){
      stop("alpha or a.wght not right length")} 
# ind holds non-zero indices and ra holds the values   
   ind<- NULL
   ra<-NULL
   da<-rep(0,2)
   if( is.na( level.index)){     
# loop over levels this is the normal case 
     for( j in 1:L){
# evaluate the H matrix at level j.
# each row of this matrix has an "a.wght[j]"  on diagonal and
# -1  for the nearest neighbor basis functions.
# edges handled differently      
        tempB<-LKrig.MRF.precision(mx[j], my[j],a.wght = a.wght[j], edge=LKinfo$edge)
# accumulate the new block in the growing matrix.
#     for the indices that are not zero      
        ind<- rbind( ind, tempB$ind+offset[j])
#     the values of the matrix at these matrix entries     
        ra<- c( ra, sqrt(alpha[j])*tempB$ra)
# increment the dimensions
        da[1]<- da[1] + tempB$da[1]
        da[2]<- da[2] + tempB$da[2]
      }
# dimensions of the full matrix   
# should be da after loop
# check this against indices in LKinfo
     if( (da[1] != LKinfo$offset[L+1])|(da[2] != LKinfo$offset[L+1]) ){
       stop("Mismatch of dimension with size in LKinfo")}
# convert to spam format:
   temp<-  spind2spam( list( ind= ind, ra=ra, da=da))}
   else{
      tempB<-LKrig.MRF.precision(mx[level.index], my[level.index],
                                 a.wght = a.wght[level.index], edge=LKinfo$edge)
      temp<-  spind2spam( list( ind= tempB$ind, ra=tempB$ra, da=tempB$da))
    }
      
   if( return.B){
     return(temp)}
   else{
# find precision matrix Q = t(B)%*%B and return
     return( t(temp)%*%(temp) )}
 }

