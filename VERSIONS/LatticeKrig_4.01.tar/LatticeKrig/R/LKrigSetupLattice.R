LKrigSetupLattice <- function(object, ...){
  UseMethod("LKrigSetupLattice")
}

LKrigSetupLattice.default<- function( object,...){
   stop("LKgeometry needs to be specified")
 }

