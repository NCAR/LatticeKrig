# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKDistance<- function(  x1, x2, delta, max.points = NULL, 
    mean.neighbor = 50, distance.type="Euclidean")
    {
# find distances between x1 and x2 but only for those pairs within
# a distance delta
#
# if distance on sphere create 3-d coordinates   
# NOTE: chordal and great circle are monotonically related
#       by    GC= theta*R  CD = 2*R*sin( theta/2)
#               theta is angle of separation in radians
#
   if( (distance.type=="Chordal") | ( distance.type=="GreatCircle") ){
   	 if( !is.null( attr(distance.type, "Radius"))){
   	 	R<- attr(distance.type, "Radius")
   	 	}
   	 	else{
   	    R<- 3963.34
   	 	}
   	 x1<- directionCosines(x1)*R
   	 x2<- directionCosines(x2)*R
   	 if( distance.type=="GreatCircle" ){
# inflate  delta cutoff to reflect chordal distance 
     deltaGC<- delta
     delta<- 2*R*sin(  deltaGC/ (2*R)) 
     }
   }
# figure out how large an array to allocate for distance matrix   
    n1 <- nrow(x1)
    n2 <- nrow(x2)
    dimension<- ncol(x1)
    if (is.null(max.points)) {
        Nmax <- max(c(n1,n2)) * mean.neighbor
    }
    else {
        Nmax <- max.points
    }

    
   out <- .Fortran("LKdist", x1 = as.double(x1), n1 = as.integer(n1), 
                             x2 = as.double(x2), n2 = as.integer(n2),
                            dim = as.integer(dimension), 
                         delta2 = as.double(delta^2),
                            ind = as.integer(rep(0, Nmax * 2)),
                             rd = as.double(rep(-1, Nmax)),
                           Nmax = as.integer(Nmax),
                          iflag = as.integer(1),
                                PACKAGE = "LatticeKrig")
# negative iflag means one has run out of space
    if (out$iflag == -1) {
        cat("temp space set at", Nmax, fill = TRUE)
        stop("Ran out of space, increase the max.points")
    }
# trim down to a sparse matrix object where the elements that have
# nonzero values (there are out$Nmax of these)
    N <- out$Nmax
# Note output distance matrix is in "spind" sparse matrix format:
    out<- list(ind = matrix(out$ind, nrow=Nmax, ncol=2)[1:N, ],
                ra = out$rd[1:N],
                da = c(n1, n2))
    # convert chordal distance to great circle            
    if(distance.type=="GreatCircle" ){
    out$ra<-  2*R* asin( out$ra/(2*R))
    }            
    return(out)
 }

LKDistanceComponents<- function(  x1, x2, delta, max.points = NULL, 
    mean.neighbor = 50, distance.type="Euclidean")
{
# find distances between x1 and x2 but only for those pairs where each 
# component is within a distance delta
#
   if( distance.type!="Euclidean"){
   	stop("Only Euclidean distance supported")
   	 	}
# figure out how large an array to allocate for distance matrix   
    n1 <- nrow(x1)
    n2 <- nrow(x2)
    dimension<- ncol(x1)
    if (is.null(max.points)) {
        Nmax <- max(c(n1,n2)) * mean.neighbor
    }
    else {
        Nmax <- max.points
    }
# note delta used here instead of delta^2  
   out <- .Fortran("LKdistComp", x1 = as.double(x1), n1 = as.integer(n1), 
                             x2 = as.double(x2), n2 = as.integer(n2),
                            dim = as.integer(dimension), 
                          delta = as.double(delta),
                            ind = as.integer(rep(0, Nmax * 2)),
                             rd = as.double(rep(-1, Nmax*dimension)),
                           Nmax = as.integer(Nmax),
                          iflag = as.integer(1),
                                PACKAGE = "LatticeKrig")
# NOTE rd is returned as a matrix 
    # negative iflag means one has run out of space
    if (out$iflag == -1) {
        cat("temp space set at", Nmax, fill = TRUE)
        stop("Ran out of space, increase the max.points")
    }
    # trim down to a sparse matrix object where the elements that have
    # nonzero values (there are out$Nmax of these)
    N <- out$Nmax
    # Note  distance information has nonzero indices in "spind" sparse matrix format
    # the component distances are organized as a matrix
    # each column of ra has the nonzero elements of a distance matrix 
    # corresponding to that column. 
    out<- list(ind = matrix(out$ind, nrow=Nmax, ncol=2         )[1:N,],
                ra = matrix(out$rd,  nrow=Nmax, ncol=dimension )[1:N,],
                da = c(n1, n2) )           
    return(out)
 }
 
directionCosines<- function( x){
# x is lat lon in degrees
     coslat <- cos((x[, 2] * pi)/180)
     sinlat <- sin((x[, 2] * pi)/180)
     coslon <- cos((x[, 1] * pi)/180)
     sinlon <- sin((x[, 1] * pi)/180)
return( cbind(coslon*coslat, sinlon*coslat, sinlat))
}

 



  LKrigNormalizeBasisFast.LKRectangle<- function( LKinfo, Level, x, ...){
# some information about the rectangular lattice at level == Level  	
  mxLevel<- (LKinfo$latticeInfo$mx)[Level]
  myLevel<- (LKinfo$latticeInfo$my)[Level]
  gridStuff<- (LKinfo$latticeInfo$grid)[[Level]]
  xmin<- gridStuff$x[1]
  ymin<- gridStuff$y[1]
  dx<-  gridStuff$x[2]-  gridStuff$x[1]
  dy<-  gridStuff$y[2]-  gridStuff$y[1] 
  overlap<-  LKinfo$basisInfo$overlap
  setupList<- ( attr( LKinfo$a.wght,"fastNormDecomp"))[[Level]]
  # convert the locations to the integer scale of the lattice
  # at the level == Level          
  xLocation<- scale( x, center= c( xmin, ymin), scale= c( dx, dy)) + 1
  nLocation<- nrow( xLocation)
# solving linear system in based on writing as a Kronecker product
# see setup function for LKrigSetupAwght.LKrectangle to see 
# definitions of the matrices below.
  return(
         .Fortran("findNorm",
                          mx = as.integer(mxLevel),
			  my = as.integer(myLevel),
		      offset = as.double(overlap),
			  Ux = as.double(setupList$Ux),
			  Dx = as.double(setupList$Dx),
			  Uy = as.double(setupList$Uy),
			  Dy = as.double(setupList$Dy),
                   nLocation = as.integer(nLocation),
                   xLocation = as.double( xLocation),
                     weights = as.double( rep(-1,nLocation) ), 
	       	           Z = matrix(as.double(0),mxLevel,myLevel)
                  )$weights
         )
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKinfoCheck <- function(object,...){
  UseMethod("LKInfoCheck")
}

LKInfoCheck.default<- function( object,...){
  LKinfo<- object
   testNames<- names(LKinfo)
   targetNames<- c("nlevel","alpha", "a.wght",          
       "normalize", "lambda","sigma","rho",
     "latticeInfo","basisInfo","distance.type")

   testMatch<- is.na( match(targetNames,testNames) ) 
  if( any( testMatch) ){
    stop(paste( "missing the required component", targetNames[ testMatch ] ))
  }
#  
  alpha <- LKinfo$alpha
   nlevel <- LKinfo$nlevel
    if ( (length(alpha) != nlevel)){
                stop( "Length of alpha does not match nlevel")}
    if( ! is.list( alpha)){
         stop("alpha should be a list")
       }
   a.wght<- LKinfo$a.wght
  if ( (length(a.wght) != nlevel)){
                stop( "Length of a.wght does not match nlevel ")
              }
  if( ! is.list( a.wght)){
         stop("a.wght should be a list")
       }
 # 
  testNames<- names(LKinfo$latticeInfo)
  targetNames<- c("m","offset", "mLevel","delta","rangeLocations")
  testMatch<- is.na(match(targetNames,testNames) )
  if( any( testMatch) ){
    stop(paste( "missing the required  latticeInfo component(s)",
                  targetNames[ testMatch ] ))
  }
# 
  testNames<- names(LKinfo$basisInfo)
  targetNames<-c("RadialBasisFunction","overlap", "V")
  testMatch<- is.na(match(targetNames,testNames) )
  if( any( testMatch) ){
    stop(paste( "missing the required  basisInfo component(s)",
                  targetNames[ testMatch ] ))
  }
  
 }






LKinfoUpdate<- function( LKinfo, ...){
   LKinfoCall<- as.list(LKinfo$call)
   argList<- list( ...)
   LKinfoCall[1] <- NULL
 # first replace the calling arguments with the values in LKinfo
  for( argName in names( LKinfoCall) ){
    tempArg<-LKinfo[[ argName]] 
    if( !is.null( tempArg) ){
      LKinfoCall[[ argName]] <- tempArg
    }
   }
 # insert new values for arguments.  
   for( argName in names( argList)){
      LKinfoCall[[ argName]] <- argList[[ argName]]}
# now call setup again to update the LKinfo object with new values.   
   do.call( "LKrigSetup" , LKinfoCall )
 }
LKrig.MLE <- function(x, y, ..., LKinfo, use.cholesky=NULL, par.grid = NULL, 
    lambda.profile = TRUE, verbose = FALSE, lowerBoundLogLambda=-16,
                      nTasks=1, taskID=1, tol=.005) {
    LKrig.args <- c(list(x = x, y = y), list(...))
    # at this point LKinfo has the correct value for the number of multiresolution levels
    par.grid <- LKrig.make.par.grid(par.grid = par.grid, LKinfo = LKinfo) 
    NG <- length(par.grid$alpha)
    # adjust the for loop from 1:NG if this
    # function is called through Rmpi (i.e. if nTasks!=1)
    # idea is that task with ID will work on
    # NG1 through NG2 -- a fraction of the total number in par.grid
     if( NG < nTasks ){
        stop("Too many tasks for the number of parameter values")
      }
    indexTemp<- round(seq( 0,NG,,nTasks+1))
    NG1<- indexTemp[taskID] + 1
    NG2<- indexTemp[taskID+1]
    #
    out <- matrix(NA, nrow = NG, ncol = 9,
                  dimnames = list(NULL, c("EffDf", "lnProfLike", "GCV", 
                  "sigma.MLE", "rho.MLE", "llambda.MLE", "lnLike", "counts value", "grad")))
    optim.counts <- rep(NA, 2)
    # evaluate parameters but do an optimzation over lambda
    lnProfileLike.max <- -1e+20
    lnLike.eval<- NULL
    llambda.opt<- NA
    for (k in NG1:NG2) {
    # if starting value is missing use the optimum from previous fit
    # this only really makes sense if other parameters have some sort of continuity from k-1 to k.
        llambda.start<- ifelse (is.na( par.grid$llambda[k]), llambda.opt,  par.grid$llambda[k] )  
     # first fit to get cholesky symbolic decomposition
        LKinfo.temp<- LKinfoUpdate( LKinfo,
                                   a.wght = (par.grid$a.wght[[k]]),
                                    alpha =  (par.grid$alpha[[k]]),
                                       nu = par.grid$nu[k],
                                   lambda = exp(llambda.start) )
    # for first pass save symbolic decomposition for M
        if( k == NG1 ){ use.cholesky <- NULL}
           obj <- do.call("LKrigFindLambda",
                      c( LKrig.args,
                        list(       LKinfo = LKinfo.temp,
                            lambda.profile = lambda.profile,
                              use.cholesky = use.cholesky,
                                        tol=tol
                            )
                        )
                        )
     # Note: if lambda.profile == FALSE the starting lambda is passed through as the "optimal" one
        llambda.opt<- obj$summary["llambda.opt"]
     # compare to current largest likelihood and update the LKinfo.MLE list if bigger.
        if ( obj$summary["lnProfLike"] > lnProfileLike.max ) {
              lnProfileLike.max <- obj$summary["lnProfLike"] 
              LKinfo.MLE <- obj$LKinfo
              lambda.MLE<- exp( llambda.opt)
        }
     # save summary results from this set of parameters.
       out[k, ] <- obj$summary
       lnLike.eval <- c( lnLike.eval, list(obj$lnLike.eval))
     #   
       if (verbose) { print( c(k,out[k,])) }
    }
    return(list(
                 summary = out,
                par.grid = par.grid,
                  LKinfo = LKinfo, 
              LKinfo.MLE = LKinfo.MLE,
             lnLike.eval = lnLike.eval,
              lambda.MLE = lambda.MLE,
                    call = match.call(),
                  taskID = taskID
                )
           )
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig <- function(x, y = NULL, weights = rep(1, nrow(x)), Z = NULL,
                  LKinfo = NULL, iseed = 123, 
	              NtrA = 20, 
               	  use.cholesky = NULL, return.cholesky = TRUE, choleskyMemory = NULL,
               	   X = NULL,  U = NULL, wX = NULL,  wU = NULL,
               	   return.wXandwU = TRUE,
               	   ...,
               	   verbose = FALSE) {
	# make sure locations are a matrix and get the rows
	x <- as.matrix(x)
	y <- as.matrix(y)
	n <- nrow(x)
	if (any(duplicated(cat.matrix(x)))) 
		stop("locations are not unique see help(LKrig) ")
	# make sure covariate is a matrix
	if (!is.null(Z)) {
		Z <- as.matrix(Z)
	}
	# check for missing values
	if (!is.null(y)) {
		if (any(is.na(y))) 
			stop("Missing values in y not allowed ")
	}

	# if LKinfo is missing create it from passed arguments   
	if (is.null(LKinfo)) {
		LKinfo <- do.call("LKrigSetup", c(list(x = x), list(...), list(verbose = verbose)))
	}
	#   At this point the LKinfo object should have the right lambda value. 
	lambda = LKinfo$lambda
	if (is.na(lambda)) {
		stop("lambda must be specified")
	}
	#   Use memory estimate from LKinfo if available
	#   NOTE: this value might be NULL in LKinfo
if (is.null(choleskyMemory)) {
		choleskyMemory <- LKinfo$choleskyMemory
	}
	# Begin computations ....
	# weighted observation vector
wy <- sqrt(weights) * y
	# Spatial drift matrix -- default is assumed to be linear in coordinates (m=2)
	# and includes possible covariate(s) -- the Z matrix.
# the choice of fixed part of the model is controlled in LKrigSetup
#
# Code should work without including a wU component i.e. there is no fixed part
# just the spatial component based on the LatticeKrig covariance.
if (is.null(wU)) {
	if( !is.null(U)){
		wU <- sqrt(weights) * U
	} else {
		if (!is.null(LKinfo$fixedFunction)) {
			wU <- sqrt(weights) * do.call(LKinfo$fixedFunction,
			                c(list(x = x, Z = Z, distance.type = LKinfo$distance.type), 
				            LKinfo$fixedFunctionArgs))			
		} 
	}	
	}
if( verbose){
	print( dim(wU))
}	
if( is.null(wU)){
			nt <- 0
			ind.drift <- NULL
			nZ <- 0
} else {
			nt <- ncol(wU)
			nZ <- ifelse(is.null(Z), 0, ncol(Z))
			ind.drift <- c(rep(TRUE, (nt - nZ)), rep(FALSE, nZ))
}
#  wX is the matrix of sum( N1*N2) basis function (columns) evaluated at the N locations (rows)
# and multiplied by square root of diagonal weight matrix
# this can be a large matrix if not encoded in sparse format.
if (is.null(wX)) {
	if( !is.null(X)){
    	wX<- diag.spam(sqrt(weights)) %*% X	
	} else {
		wX <- diag.spam(sqrt(weights)) %*% LKrig.basis(x, LKinfo, verbose = verbose)
		
	}
	}
	if( verbose){
		print( dim( wX))
	}
	#   square root of precision matrix of the lattice process
	#   solve(t(H)%*%H) is proportional to the covariance matrix of the Markov Random Field
Q <- LKrig.precision(LKinfo)
	# M is the regularized regression matrix that is the key to the entire algorithm:
	M <- t(wX) %*% wX + lambda * (Q)
	nzero <- length(M@entries)
	# find Cholesky square root of M
	#  This is where the heavy lifting happens!  M is in sparse format so
#   by the overloading is a sparse cholesky decomposition.
#  if this function has been coded efficiently this step should dominate
#  all other computations.
#  If  a previous sparse cholesky decoposition is passed then the
#  pattern of sparseness is used for the decoposition.
#  This can speed the computation as the symbolic decomposition part of the
#  sparse Cholesky is a nontrivial step. The condition is that
#  the current 'M' matrix  has the same sparse pattern as that
#  which resulted in the factorization  cholesky as 'use.cholesky'
if (is.null(use.cholesky)) {
		Mc <- chol(M, memory = choleskyMemory)
	} else {
		Mc <- update.spam.chol.NgPeyton(use.cholesky, M)
	}
	# partially fill object list with some components
	object <- list(x = x, y = y, weights = weights, Z = Z, nZ = nZ, ind.drift = ind.drift, 
		LKinfo = LKinfo, lambda = lambda)
	# use Mc to find coefficients of estimate
	out1 <- LKrig.coef(Mc, wX, wU, wy, lambda, weights)
	if (verbose) {
		cat(" d.coef", out1$d.coef, fill = TRUE)
	}
	# add in components from coefficient estimates
	object <- c(object, out1)
	# compute predicted values    
	fitted.values <- (wX %*% out1$c.coef)/sqrt(weights)
	if (!is.null(LKinfo$fixedFunction) | !is.null(wU)) {
		fitted.values.fixed <- (wU %*% out1$d.coef)/sqrt(weights)
		fitted.values <- fitted.values.fixed + fitted.values
	}
	# For reference: fitted.values <- predict.LKrig(object, x, Znew = object$Z)
	residuals <- y - fitted.values
	out2 <- LKrig.lnPlike(Mc, Q, y, lambda, residuals, weights, LKinfo$sigma, LKinfo$rho, 
		choleskyMemory = choleskyMemory)
	object <- c(object, out2)
	# estimate trace by Monte Carlo if NtrA greater than zero
	if (NtrA > 0) {
		out3 <- LKrig.traceA(Mc, wX, wU, lambda, weights, NtrA, iseed)
		# find GCV using this trace estimate
		out3$GCV = (sum(weights * (residuals)^2)/n)/(1 - out3$trA.est/n)^2
	} else {
		out3 <- list(trA.est = NA, trA.SE = NA, GCV = NA)
	}
	object <- c(object, out3)
	# the output object
	# note the ifelse switch whether to return the big cholesky decomposition
# and/or the weighted basis matrix wX
object <- c(object, list(fitted.values = fitted.values, residuals = residuals, lambda.fixed = lambda, 
		nonzero.entries = nzero, nt = nt, eff.df = out3$trA.est, call = match.call()))
	if (return.cholesky) {
		object$Mc <- Mc
	}
	if (return.wXandwU) {
		object$X <- wX
		object$U <- wU
	}
	# set the class and return.
	class(object) <- "LKrig"
	return(object)
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.basis <- function(x1, LKinfo, verbose = FALSE)
  {
    nlevel        <- LKinfo$nlevel
    delta         <- LKinfo$latticeInfo$delta
    overlap       <- LKinfo$basisInfo$overlap
    normalize     <- LKinfo$normalize
    distance.type <- LKinfo$distance.type
    fast          <-  attr( LKinfo$a.wght,"fastNormalize")
    V <- LKinfo$basisInfo$V
    # We will transform (scale and rotate) x matrix of locations by   x%*% t(solve(V))
    # 
    # For the radial basis functions this
    # will imply that the Euclidean distance norm used between two vectors X1 and X2
    # is  t(X1-X2) solve(A) (X1-X2)  with A = (V %*%t(V))
    # Here's the deal on the linear transformation V:
    # It should be equivalent to just transforming the locations outside of LatticeKrig.
    # Where ever the observation locations are used
    # they are first transformed with t(solve(V))).
    # Surprisingly this only needs to happen in one place below and in LKrig.setup to
    # determine the grid centers.
    #
    # The RBF centers and the delta scale factor, however, assumed to be
    # in the transformed scale and so a  transformation is not needed.
    # see LKrig.setup for how the centers are determined.
    # The concept is that if LKrig was called with the transformed locations
    # ( x%*%t( solve(V)) instead of x
    # and V set to diag( c(1,1) ) one would get the same results.
    # as passing a non identity V.
    #
    # accumulate matrix column by column in PHI
    PHI <- NULL
    if( !is.na( V[1]) ){     
    x1<- x1 %*% t(solve(V))
        
    }
    if( verbose){
          cat(" Dim x1 ",  dim( x1), fill=TRUE)
        }
    for (l in 1:nlevel) {
        # Loop over levels and evaluate basis functions in that level.
        # Note that all the center information based on the regualr grids is
        # taken from the LKinfo object
        centers <- LKrigLatticeCenters(LKinfo, Level=l)
        #  set the range of basis functions, they are assumed to be zero outside
        #  the radius basis.delta and according to the distance type.
        basis.delta <- delta[l] * overlap
        # 
        # There are two choices for the type of basis functions
        # 
        if(LKinfo$basisInfo$BasisType=="Radial" ){ 
        PHItemp <- Radial.basis(  x1, centers, basis.delta,
                                max.points = LKinfo$basisInfo$max.points,
                             mean.neighbor = LKinfo$basisInfo$mean.neighbor, 
                       RadialBasisFunction = get(LKinfo$basisInfo$RadialBasisFunction),
                             distance.type = LKinfo$distance.type)
                             }
        if(LKinfo$basisInfo$BasisType=="Tensor" ){              
        PHItemp <- Tensor.basis(  x1, centers, basis.delta,
                                max.points = LKinfo$basisInfo$max.points,
                             mean.neighbor = LKinfo$basisInfo$mean.neighbor, 
                       TensorBasisFunction = get(LKinfo$basisInfo$TensorBasisFunction),
                             distance.type = LKinfo$distance.type)
                             }        	                            
        if( verbose){
          cat(" Dim PHI level", l, dim( PHItemp), fill=TRUE)
        }
        if (normalize) {  
        	if( !fast ){
        	# the default choice should work for all models	
               wght<-  LKrigNormalizeBasis( LKinfo,  Level=l,  PHI=PHItemp)               
            }
            else{ 
            # potentially a faster method that is likely very specific
            # to a particular more e.g. LKrectangle with stationary first order GMF
            # NOTE that locations are passed here rather than the basis matrix	
               wght<- LKrigNormalizeBasisFast(LKinfo,  Level=l,  x=x1)
            	}
# now normalize the basis functions by the weights treat the case with one point separately
# wghts are in scale of inverse marginal variance of process
           if( nrow( x1)>1){
              PHItemp <- diag.spam( 1/sqrt(wght) ) %*% PHItemp
           }
          else{
              PHItemp@entries <- PHItemp@entries/sqrt(wght)
              }
         if( verbose){
          cat("normalized basis functions", fill=TRUE)
        }    
        }   
        # accumulate this new level of basis functions.
        PHI <- cbind(PHI, PHItemp)
    }
    # include a spatially varying multiplication of process.
    if (!is.null( LKinfo$rho.object) ) {
        wght <- c(predict(LKinfo$rho.object, x1))
        PHI <- diag.spam(sqrt(wght)) %*% PHI
        }
    # attach  LKinfo list to the matrix to help identify how the basis functions
    # are organized.
    attr(PHI, which = "LKinfo") <- LKinfo
    return(PHI)
}


# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.coef <- function(Mc, wPHI, wT.matrix, wy, lambda, weights) {
    if (length(lambda) > 1) {
        stop("lambda must be a scalar")
    }
    if( !is.null(wT.matrix) ){
        A <- forwardsolve(Mc, transpose = TRUE, t(wPHI) %*% wT.matrix, 
                              upper.tri = TRUE)
        A <- backsolve(Mc, A)
        A <- t(wT.matrix) %*% (wT.matrix - wPHI %*% A)/lambda
#   A is  (T^t M^{-1} T)
        b <- forwardsolve(Mc, transpose = TRUE, t(wPHI) %*% wy, upper.tri = TRUE)
        b <- backsolve(Mc, b)
        b <- t(wT.matrix) %*% (wy - wPHI %*% b)/lambda
# b is   (T^t M^{-1} y)
# Save the intermediate matrix   (T^t M^{-1} T) ^{-1}
# this the GLS covariance matrix of estimated coefficients
# should be small for this to be efficient code -- the default is 3X3
        Omega <- solve(A)
# GLS estimates
        d.coef <- Omega %*% b
        residual<- wy - wT.matrix %*% d.coef
   }
   else{
       Omega<- NULL
       d.coef<- NULL
       residual<- wy
   }     
# coefficients of basis functions.
    c.coef <- forwardsolve(Mc, transpose = TRUE,
                       t(wPHI) %*% (residual), upper.tri = TRUE)
    c.coef <- backsolve(Mc, c.coef)
    c.mKrig <- sqrt(weights) * (residual - wPHI %*% c.coef)/lambda
    
    return(list(c.coef = c.coef, d.coef = d.coef, Omega = Omega, 
        c.mKrig = c.mKrig))
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.cov <- function(x1, x2 = NULL, LKinfo, C = NA, marginal = FALSE) {
	PHI1 <- LKrig.basis(x1, LKinfo)
	# sparse precision matrix for the basis coeficients	
	Q <- LKrig.precision(LKinfo)
	Qc <- chol(Q, memory = LKinfo$choleskyMemory)
	# note: construction of lattice basis depends on alpha and a.wght  and normalizes
	# the basis 
if (!marginal) {
		if (is.null(x2)) {
			PHI2 <- PHI1
		} else {
			PHI2 <- LKrig.basis(x2, LKinfo)
		}
		if (is.na(C[1])) {
			A <- forwardsolve(Qc, transpose = TRUE, t(PHI2), upper.tri = TRUE)
			A <- backsolve(Qc, A)
			return(PHI1 %*% A)
		} else {
			A <- forwardsolve(Qc, transpose = TRUE, t(PHI2) %*% C, upper.tri = TRUE)
			A <- backsolve(Qc, A)
			return(PHI1 %*% A)
		}
	} else {
		if (!is.null(x2)) {
			stop("x2 should not be passed to find marginal variance")
		}
#  NOTE: if LKinfo$normalize = TRUE then basis functions
#   will be already normalized so that the marginal varinace is one
#   without the additional factor of rho.
		PHI <- LKrig.basis(x1, LKinfo)
		marginal.variance <- LKrig.quadraticform(LKrig.precision(LKinfo), 
			PHI, choleskyMemory = LKinfo$choleskyMemory)
		if (!is.null(LKinfo$rho.object)) {
			# add in additional scaling if part of covariance model
			marginal.variance <- marginal.variance * predict(LKinfo$rho.object, 
				x1)
		}
		return(marginal.variance)
	}
	# should not get here.
	}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.cov.plot <- function(LKinfo, NP = 200, center = NULL, 
    xlim = NULL, ylim = NULL) {
    grid.info <- LKinfo$latticeInfo$rangeLocations
    if (is.null(xlim)) {
        xlim <-grid.info[,1]
    }
    ux <- seq(xlim[1], xlim[2], , NP)
    
    if (is.null(ylim)) {
        ylim <- grid.info[,2]
    }
    uy <- seq(ylim[1], ylim[2], , NP)
    
    if (is.null(center)) {
        center <- rbind(c(ux[NP/2], uy[NP/2]))
    }
    x1 <- cbind(ux, rep(center[2], NP))
    x2 <- rbind(center)
    d <- c(rdist(x1, x2))
    # evaluate the covariance from the LKinfo object devised from table
    # to approximate the Matern in the X direction
    y <- c(LKrig.cov(x1, x2, LKinfo))
    x1 <- cbind(rep(center[1], NP), uy)
    d2 <- c(rdist(x1, x2))
    
    # same in Y direction
    y2 <- c(LKrig.cov(x1, x2, LKinfo))
    return(list(d = cbind(d, d2), u = cbind(ux, uy), cov = cbind(y, 
        y2), center = center, LKinfo = LKinfo))
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.lnPlike <- function(Mc, Q, y, lambda, residuals, weights, sigma = NA, 
	rho = NA, choleskyMemory = NULL) {
	# sanity check on lambda being ratio of sigma^2 and rho
	# if sigma and rho are passed.
if (!is.na(rho)) {
		if ((sigma^2/rho) != lambda) {
			stop(" sigma, rho and lambda do not match up")
		}
	}
	#
	n <- nrow(y)
	m <- dim(Q)[1]
	# find log determinant of reg matrix for use in the log likeihood
	lnDetReg <- 2 * sum(log(diag(Mc)))
	# log determinant of precision matrix.
	lnDetQ <- 2 * sum(log(diag(chol(Q, memory = choleskyMemory))))
	# now apply a miraculous determinant identity (Sylvester''s theorem)
	#  det( I + UV) = det( I + VU)    providing UV is square
# or more generally
#  det( A + UV) = det(A) det( I + V A^{-1}U)
#  or as we use it
#  ln(det( I + V A^{-1}U)) = ln( det(  A + UV)) - ln( det(A))
#
lnDetCov <- lnDetReg - lnDetQ + (n - m) * log(lambda) - sum(log(weights))
	# finding quadratic form
	# this uses a shortcut formula in terms of
# the residuals
c.mKrig <- weights * residuals/lambda
	# MLE estimate of rho and sigma
	# these are derived by assuming Y is  MN(  Td, rho*M )
quad.form <- c(colSums(as.matrix(c.mKrig * y)))
	rho.MLE <- quad.form/n
	shat.MLE <- sigma.MLE <- sqrt(lambda * rho.MLE)
	# the  log profile likehood with  rho.MLE  and  dhat substituted
	# leaving a profile for just lambda.
# note that this is _not_  -2*loglike just the log and
# includes the constants
lnProfileLike <- (-(n/2) - log(2 * pi) * (n/2) - (n/2) * log(rho.MLE) - 
		(1/2) * lnDetCov)
	# find log likelihood without profiling if sigma and rho have been passed.
	# NOTE: this assumes that  lambda == sigma^2/rho
if (!is.na(rho)) {
		lnLike <- (-(quad.form)/(2 * rho) - log(2 * pi) * (n/2) - (n/2) * 
			log(rho) - (1/2) * lnDetCov)
		lnLike.FULL <- sum(lnLike)
	} else {
		lnLike <- NA
		lnLike.FULL <- NA
	}
	# the full ln profile likelihood  is found 
	# by assuming the replicate fields (columns of y)
	# are independent and putting in a pooled MLE for rho.
rho.MLE.FULL <- mean(rho.MLE)
	sigma.MLE.FULL <- sqrt(lambda * rho.MLE.FULL)
	lnProfileLike.FULL <- sum(-(n/2) - log(2 * pi) * (n/2) - (n/2) * log(rho.MLE.FULL) - 
		(1/2) * lnDetCov)

	#
	return(list(lnProfileLike = lnProfileLike,
	                  rho.MLE = rho.MLE,
	                 shat.MLE = shat.MLE, 
	          		sigma.MLE = shat.MLE,
	          		    sigma = sigma,
	          		      rho = rho,
	          		   lnLike = lnLike,
	              lnLike.FULL = lnLike.FULL, 
           	     rho.MLE.FULL = rho.MLE.FULL,
           	   sigma.MLE.FULL = sigma.MLE.FULL,
           lnProfileLike.FULL = lnProfileLike.FULL, 
             		quad.form = quad.form,
             		 lnDetCov = lnDetCov))
}


# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or

LKrig.make.par.grid <- function(par.grid = NULL, LKinfo = NULL) {    
    # if par.grid is missing find all the information for the LKinfo list
    if (is.null(par.grid)) {
        par.grid <- list()
        par.grid$a.wght <- list(LKinfo$a.wght)
        par.grid$alpha <- list(LKinfo$alpha)
        par.grid$llambda <- ifelse(is.na(LKinfo$lambda), 0, log(LKinfo$lambda))
        return(par.grid)
    }
    if (is.null(par.grid$llambda)) {
        par.grid$llambda <- NA
    }
   # if needed create alpha from nu
    if( !is.null(par.grid$nu)){
        nlevel<- LKinfo$nlevel
        M<- length( par.grid$nu)
        alpha<- matrix( NA,nrow=M, ncol=LKinfo$nlevel)
        for ( k in 1:M){
          alphaTemp <- exp(-2 * (1:nlevel) * par.grid$nu[k])
          alpha[k,] <- alphaTemp/sum(alphaTemp)
        }
        par.grid$alpha<- alpha
     } 
    # if needed create alpha from gamma
    if (!is.null(par.grid$gamma)) {
        if (!is.matrix(par.grid$gamma)) {
            par.grid$gamma <- cbind(par.grid$gamma)
        }
        par.grid$alpha <- cbind(1, exp(par.grid$gamma))
        for (j in 1:nrow(par.grid$gamma)) {
            par.grid$alpha[j, ] <- par.grid$alpha[j, ]/sum(par.grid$alpha[j, 
                ])
        }
    }
    #convert alpha to a list format 
    if (is.matrix(par.grid$alpha)) {
        M <- nrow(par.grid$alpha)
        temp.list <- list()
        for (k in (1:M)) {
            temp.list <- c(temp.list, list(par.grid$alpha[k, 
                ]))
        }
        par.grid$alpha <- temp.list
    }
    #convert a.wght to list format
    if (is.matrix(par.grid$a.wght)) {
        M <- nrow(par.grid$a.wght)
        temp.list <- list()
        for (k in (1:M)) {
            temp.list <- c(temp.list, list(par.grid$a.wght[k, 
                ]))
        }
        par.grid$a.wght <- temp.list
    }
    # some checks
    NG <- length(par.grid$alpha)
    if (length(par.grid$llambda) != NG) {
        stop("llambda values not same length as alpha")
    }
    if (length(par.grid$a.wght) != NG) {
        stop("a.wght values not same length as alpha")
    }
    return(par.grid)
}
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

which.max.matrix <- function(z) {
    if (!is.matrix(z)) {
        stop("Not a matrix")
    }
    m <- nrow(z)
    n <- ncol(z)
    # take care of NAs
    ind <- which.max(z)
    iy <- trunc((ind - 1)/m) + 1
    ix <- ind - (iy - 1) * m
    return(cbind(ix, iy))
}


which.max.image <- function(obj) {
    ind.z <- which.max.matrix(obj$z)
    return(list(x = obj$x[ind.z[, 1]], y = obj$y[ind.z[, 2]], 
        z = obj$z[ind.z], ind = ind.z))
}

LKArrayShift<-  function (A, shift) 
{
    L <- dim(A)
    B<- array( NA, L)
    N<- prod(L)
    if (any(abs(shift) > L) ) {
        stop("shift exceeds array dimensions")
    }
    dimension<- length(L)
    indexListSource<- indexListTarget<- NULL
     for( k in 1:dimension) {
     	  indexListSource<- c( indexListSource, list( c(1:L[k]) ) )    	   
     	  tempIndex <-  1:L[k] + shift[k]
# set indices beyond range (i.e. boundaries of lattice to NAs)
          tempIndex[  (tempIndex<1) | (tempIndex > L[k]) ] <- NA     	   
 	      indexListTarget <- c( indexListTarget, list( tempIndex ) )
     	  }  
# indices are organized as matrices with each column representing a dimension     	  
    indexSource <- as.matrix( expand.grid( indexListSource) )
    indexTarget <- as.matrix( expand.grid( indexListTarget) )
# identify NAs  not sure if this code is too cute 
    inRange <-  rowSums( is.na(indexTarget) ) == 0
    B[ indexTarget[inRange,]] <- A[ indexSource[inRange,]] 
    return( B)
}

# A<- array( 1:(2*4*3), c( 3,4,2)); shift<- c( 1,0,0); LKArrayShift( A, shift=c( 0,1,0))

LKrig.rowshift <- function(A, shift.row, shift.col) {
    mx <- dim(A)[1]
    my <- dim(A)[2]
    if (abs(shift.row) > mx) {
        stop("shift exceeds matrix dimension")
    }
    if (shift.row < 0) {
        i.target <- 1:(mx + shift.row)
        i.source <- (-shift.row + 1):mx
    }
    else {
        i.target <- (shift.row + 1):mx
        i.source <- (1:(mx - shift.row))
    }
    
    B <- matrix(NA, mx, my)
    B[i.target, ] <- A[i.source, ]
    return(B)
}

LKrig.rowshift.periodic <- function(A, shift.row) {
    mx <- dim(A)[1]
    if (abs(shift.row) > mx) {
        stop("shift exceeds matrix dimension")
    }
    if (shift.row < 0) {
        i.source <- c((-shift.row + 1):mx, 1:(-shift.row))
    }
    else {
        i.source <- c(mx - (shift.row:1) + 1, 1:(mx - shift.row))
    }
    return(A[i.source, ])
}

LKrig.shift.matrix <- function(A, shift.row = 0, shift.col = 0, 
    periodic = c(FALSE, FALSE)) {
    if (shift.row != 0) {
        if (!periodic[1]) {
            A <- LKrig.rowshift(A, shift.row = shift.row)
        }
        else {
            A <- LKrig.rowshift.periodic(A, shift.row = shift.row)
        }
    }
    if (shift.col != 0) {
        if (!periodic[2]) {
            A <- t(LKrig.rowshift(t(A), shift.row = shift.col))
        }
        else {
            A <- t(LKrig.rowshift.periodic(t(A), shift.row = shift.col))
        }
    }
    return(A)
}

repMatrix<- function(A, times=1, each=1, byrow=TRUE){
   A<- as.matrix(A)
   if( !byrow){ A<- t(A) }
   nSize<- nrow(A)*each*times
   nColumn<- ncol(A)
   B<- matrix(NA, nSize, ncol=nColumn)
   for( k in 1:nColumn){
      B[,k] <- rep( A[,k], times=times, each=each)
    }
  if( !byrow){ B<- t(B)}
   B
 }

expandMatrix0<- function( A, B){
   A<- as.matrix(A)
   B<- as.matrix(B)
   m1<- nrow( A)
   m2<- nrow( B)
   cbind(repMatrix( A,times=m2, each=1), repMatrix( B, times=1, each=m1))
 }

expandMatrix<- function( ...){
  matrices<- list(...)
  N<- length( matrices)
  tempM<- matrices[[1]]
  for( k in 2:N){
    tempM<- expandMatrix0(tempM, matrices[[k]])
  } 
  tempM
}
    
 expandMList <- function( Mlist, byrow=TRUE){
   N<- length( Mlist)
   
   for( k in 2:N){
     mtimes<- nrow( as.matrix(Mlist[[k]]))
     each<- nrow( as.matrix( Mlist[[1]]))
     for( l in 1:(k-1)){
      Mlist[[l]] <- repMatrix(Mlist[[l]], byrow=byrow,times=mtimes)
    }
     Mlist[[k]]<- repMatrix( Mlist[[k]], byrow=byrow, each =each)
   }
     Mlist
   }
  
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.precision <- function(LKinfo, return.B = FALSE,
                                   verbose=FALSE) { 
    L <- LKinfo$nlevel
    offset <- LKinfo$latticeInfo$offset
    # some checks on arguments
    LKinfoCheck(LKinfo)
    # ind holds non-zero indices and ra holds the values
    ind <- NULL
    ra <- NULL
    da <- rep(0, 2)
        # loop over levels
        for (j in 1:L) {
            # evaluate the SAR matrix at level j.
            tempB<- LKrigSAR( LKinfo, Level=j)
            # multiply this block by 1/ sqrt(diag( alpha[[j]]))
            alpha.level <- (LKinfo$alpha)[[j]]
            if (length(alpha.level) == 1) {
                tempra <- 1/sqrt(alpha.level[1]) * tempB$ra
            }
            else {
                rowindices <- tempB$ind[, 1]
                tempra <- 1/sqrt(alpha.level[rowindices]) * tempB$ra
            }
            # accumulate the new block
            # for the indices that are not zero
            ra <- c(ra, tempra)
            ind <- rbind(ind, tempB$ind + offset[j])
            # increment the dimensions
            da[1] <- da[1] + tempB$da[1]
            da[2] <- da[2] + tempB$da[2]
        }
        # dimensions of the full matrix
        # should be da after loop
        # check this against indices in LKinfo
        #
        if ((da[1] != offset[L + 1]) | (da[2] != offset[L + 
            1])) {
            stop("Mismatch of dimension with size in LKinfo")
        }
        # convert to spam format:
        temp <- LKrig.spind2spam(list(ind = ind, ra = ra, da = da))
    if (return.B) {
        return(temp)
    }
    else {
        # find precision matrix Q = t(B)%*%B and return
        return(t(temp) %*% (temp))
    }
}

LKrig.quadraticform <- function(Q, PHI, choleskyMemory=NULL) {
    #   finds     the quadratic forms    PHI_j^T Q.inverse PHI_j  where PHI_j is the jth row of
    #   PHI.
    #   The loop is to avoid using memory for the entire problem if more than 2000 elements.
    nrow <- dim(PHI)[1]
    choleskyPrecision<- chol(Q, memory = choleskyMemory)
    if (nrow > 1) {
        BLOCKSIZE <- 2000
        wght <- rep(NA, nrow)
        counter <- 1
        while (counter < nrow) {
            ind <- counter:min((counter + BLOCKSIZE), nrow)
            A <- forwardsolve(l = choleskyPrecision, transpose = TRUE, 
                x = t(PHI[ind, ]), upper.tri = TRUE)
            wght[ind] <- c(colSums(A^2))
            counter <- counter + BLOCKSIZE
        }
    }
    else {
        # Unfortunately the case when there is one row needs to be handled separately.
        A <- forwardsolve(l = choleskyPrecision, transpose = TRUE,
                           x = t(PHI), upper.tri = TRUE)
        wght <- sum(A^2)
    }
    return(wght)
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.sim <- function(x1, LKinfo, M = 1, just.coefficients = FALSE) {
	Q <- LKrig.precision(LKinfo)
	#
	#  Q is precision matrix of the coefficients -- not of the field
#  last step does the multiplication to go from coefficients to evaluating
#  values at the field
#  Q = t(H)%*%H = inv((Sigma)
#  So   Sigma= Hi%*% t(Hi)
#  find u= t(Hi) %*% N(0,1)   then cov(u) = t(Hi)%*%Hi
#  Hi is upper triangular
#
# snippet of code to test the algebra ...
#   x<-seq( 0,1,,20); Sigma<- exp(-rdist( x,x)/2.5); Q<- solve( Sigma)
#   Mc <- chol(Q); H<- Mc ; Hi<- solve(H);
#   test.for.zero( Q, t(H)%*%H); test.for.zero(Sigma, Hi%*%t(Hi))
#   E<- rnorm(20);  u1<- Hi%*% E ;   u2<-backsolve(Mc,E)
#   test.for.zero(u1,u2)
#
Qc <- chol(Q, memory = LKinfo$choleskyMemory)
	m <- LKinfo$latticeInfo$m
	E <- matrix(rnorm(M * m), nrow = m, ncol = M)
	A <- backsolve(Qc, E)
	if (just.coefficients) {
		return(A)
	} else {
		PHI1 <- LKrig.basis(x1, LKinfo)
		return(PHI1 %*% A)
	}
}

LKrig.sim.conditional <- function(LKrigObj, M = 1, x.grid = NULL, 
    grid.list = NULL, nx = 80, ny = 80, ..., Z.grid = NULL, seed=42) {
    # generate grid if not specified
    if (is.null(x.grid)) {
        if (is.null(grid.list)) {
            grid.list <- fields.x.to.grid(LKrigObj$x, nx = nx, ny = ny)
        }
        x.grid <- make.surface.grid(grid.list)
    }
    # NOTE the name x.grid may be misleading because it just needs to a column matrix of
    # locations. It need not follow any regualr pattern.
    # now generate the error surfaces
    # begin block
    # create vector of seeds if needed
    if( length(seed)==1){
        seeds<- seed + ( 0:(M-1))
      }
    #
    g.conditional.draw <-    matrix(NA, ncol = M, nrow = nrow(x.grid))
    d.coef.draw<- matrix(NA, ncol = M, nrow = length( LKrigObj$d.coef) )
    N <- nrow(LKrigObj$x)  
    # complete set of locations to evaluate the field must include the observations too
    PHIGrid<- LKrig.basis(x.grid,LKrigObj$LKinfo)
    PHIObs<- LKrig.basis(LKrigObj$x,LKrigObj$LKinfo)
    # predicted field at grid from the actual data

    spatialPart<- (PHIGrid%*% LKrigObj$c.coef)
    fixedPart<- predictLKrigFixedFunction(LKrigObj, xnew=x.grid, Znew = Z.grid)
    ghat <- fixedPart + spatialPart
    for (k in 1:M) {
        cat(k, " ")
        out<- simConditionalDraw( k,  LKrigObj, ghat, x.grid, Z.grid,  PHIGrid, PHIObs, seeds, ...)
        d.coef.draw[,k] <- out$d.coef
        g.conditional.draw[, k] <- out$g.conditional
    }
    #
    return(list(x.grid = x.grid, ghat = ghat, g.draw = g.conditional.draw,
                           d.coef.draw= d.coef.draw))
}

simConditionalDraw <- function(index=1,  LKrigObj, ghat, x.grid, Z.grid, PHIGrid, PHIObs, seeds= 123, ...){
require(LatticeKrig)
        set.seed( seeds[index] )
# generate process at grid and also on the observation locations.
        simCoefficients<- LKrig.sim(LKinfo = LKrigObj$LKinfo, just.coefficients=TRUE)
        g.unconditional.data <-sqrt(LKrigObj$rho.MLE) *PHIObs%*%simCoefficients 
        g.unconditional.grid <-sqrt(LKrigObj$rho.MLE) *PHIGrid%*%simCoefficients 
        # generate a synthetic data set with fixed part set to zero.
        N<- length( LKrigObj$y)
        y.synthetic.data <- g.unconditional.data + LKrigObj$sigma.MLE * 
            rnorm(N)/LKrigObj$weights
        # use LKrig to find the predictions for the xgrid locations
        # NOTE that LKrig will still estimate the fixed part.
        # and it is important to include this part of estimate
        obj.fit.synthetic <- LKrig(LKrigObj$x, y.synthetic.data, LKinfo = LKrigObj$LKinfo, 
                                   lambda = LKrigObj$lambda, Z = LKrigObj$Z,
                                   weights = LKrigObj$weights,
                                   wPHI = LKrigObj$wPHI, use.cholesky = LKrigObj$Mc, ...)
        d.coef <- obj.fit.synthetic$d.coef
        #
        # predict field
        spatialPart<- (PHIGrid%*% obj.fit.synthetic$c.coef)
        fixedPart<- predictLKrigFixedFunction(obj.fit.synthetic, xnew=x.grid, Znew = Z.grid)
        ghat.synthetic<-  fixedPart + spatialPart
        # add prediction error to the condition mean from the actual data
        g.conditional <- ghat + (g.unconditional.grid -  ghat.synthetic)
        # NOTE: sampling variablity for fixed part is built in too
        # because d.coef are estimated and included in the prediction. 
return(
       list( g.conditional = g.conditional, d.coef = d.coef) )
}

LKrig.spind2spam <- function(obj, add.zero.rows = TRUE) {
    # Check if there is a missing row. If so either stop or fill in these row with a zero value
    if (length(unique(obj$ind[, 1])) < obj$da[1]) {
        # The offending rows -- concise but inpentrable R code!
        ind.missing <- (1:obj$da[1])[-unique(obj$ind[, 1])]
        N.missing <- length(ind.missing)
        if (!add.zero.rows) {
            cat(N.missing, " missing row(s)", fill = TRUE)
            stop("Can not coerce to spam format with add.zero.rows==FALSE")
        }
        else {
            # put a hard zero in the first column of each missing row
            obj$ind <- rbind(obj$ind, cbind(ind.missing, rep(1, 
                N.missing)))
            obj$ra <- c(obj$ra, rep(0, N.missing))
        }
    }
    # sort on rows and then columns to make sure they are in order
    ii <- order(obj$ind[, 1], obj$ind[, 2])
    #    shuffle indices and entries so they are in row order
    obj$ind <- obj$ind[ii, ]
    obj$ra <- obj$ra[ii]
    ia <- obj$ind[, 1]
    # define total number of nonzero elements
    M <- length(ia)
    # find places where rows change
    hold <- diff(c(0, ia, M + 1))
    # Note: 1:M is the cumsum for elements.
    ia <- (1:(M + 1))[hold != 0]
    return(new("spam", entries = as.numeric(obj$ra), colindices = as.integer(obj$ind[, 
        2]), rowpointers = as.integer(ia), dimension = as.integer(obj$da)))
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.traceA <- function(Mc, wPHI, wT.matrix, lambda, 
    weights, NtrA, iseed = NA) {
    if (exists(".Random.seed", 1)) {
        save.seed <- .Random.seed
    }
    else {
        save.seed <- NA
    }
    n <- length(weights)
    # set  new seed to use for Monte Carlo estimate of trace A(lambda)
    if (!is.na(iseed)) {
        set.seed(iseed)
    }
    # generate N(0,1)
    wEy <- matrix(rnorm(NtrA * n), n, NtrA) * sqrt(weights)
    # restore  original random seed
    if (!is.na(iseed) & !is.na(save.seed[1])) {
        assign(".Random.seed", save.seed, pos = 1)
    }
    #
    out3 <- LKrig.coef(Mc, wPHI, wT.matrix, wEy, lambda, weights) 
    wEyhat <- (wPHI %*% out3$c.coef)
    if( !is.null(wT.matrix) ){
        wEyhat <- wEyhat + wT.matrix %*% out3$d.coef
    }
    trA.info <- colSums((wEy * wEyhat)/weights)
    trA.est <- mean(trA.info)
    trA.SE <- sqrt(var(trA.info)/length(trA.info))
    list(trA.est = trA.est, trA.SE = trA.SE)
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigDefaultFixedFunction <- function(x, Z = NULL, m=2,  distance.type = "Euclidean") {
    # default function to create matrix for fixed part of model
    #  x, Z, and drop.Z are required
    #  Note that the degree of the polynomial is by convention (m-1)
    #  returned matrix must have the columns from Z last.
    #  currently LKrig defaults m to 2.
    #
    # NOTE: if Z is NULL the effect of cbind( A, Z)
    # is to return A 
    #

    if( !is.null(Z)){
      if( nrow(Z)!=nrow(x)){
          stop(" x (locations) and Z (covariates) have different numbers of rows")
        }
    }
    if (distance.type == "Euclidean") {
        T.matrix<- cbind(fields.mkpoly(x, m = m), Z)
     
    }
    if (distance.type == "Chordal" |distance.type == "GreatCircle" ) {
        # spatial polynomial only in latitude
       T.matrix <-  cbind(fields.mkpoly(x[, 2], m = m), Z)
    }
      return( T.matrix)
    }

LKrigFindLambda <- function(x, y, ...,  LKinfo,
                            use.cholesky=NULL, 
                            verbose = FALSE,
                            lambda.profile=TRUE,
                            lowerBoundLogLambda=-16,
                            tol=.005) {
# parts of the LKrig call that will be fixed.  (except updates to LKinfo)                           	
    LKrigArgs <- c(list(x = x, y = y), list( ...),
                   list( LKinfo=LKinfo, NtrA=ifelse( lambda.profile, 0, 20) ))
    out <- rep(NA, 9)
    names( out) <-  c("EffDf", "lnProfLike", "GCV", 
        "sigma.MLE", "rho.MLE", "llambda.opt", "lnLike", "counts value", "grad")
    capture.evaluations <- matrix(NA, ncol = 4, nrow = 1, 
                dimnames = list(NULL, c("lambda", "rho.MLE",
                                         "sigma.MLE", "lnProfileLike.FULL")))
    optim.counts<-  NA
    llambda.start<- log( LKrigArgs$LKinfo$lambda )
    if( is.na(llambda.start)){ llambda.start<- -1 }
  
#    
# first fit to get cholesky symbolic decomposition  and wX and wU matrices
# Note that if use.cholesky != NULL then the symbolic decomposition information is
# used from the passed object.
    LKrigArgs$LKinfo$lambda<- exp( llambda.start)
    LKrigObject <- do.call("LKrig", c(
                             LKrigArgs,
                             list( 
                                   use.cholesky=use.cholesky,
                                   return.cholesky = TRUE,
                                   return.wXandwU=TRUE,
                                   verbose=FALSE)))
    capture.evaluations[1,] <-  unlist(LKrigObject [c("lambda", "rho.MLE",
                                                      "sigma.MLE", "lnProfileLike.FULL")])
                                                 
    llambda.opt<- llambda.start
    Mc.save<- LKrigObject$Mc
    wX.save<- LKrigObject$wX
    wU.save<- LKrigObject$wU
    print( dim( wX.save))
#    
##### in most cases now optimze likelihood over log lambda    
   if( lambda.profile){
#  temporary function used in optimizer
#   
# objective function    
    temp.fn <- function(x) {
    	 LKrigArgs$LKinfo$lambda<- exp( x)
         hold <- do.call("LKrig",
          c(LKrigArgs, list(use.cholesky = Mc.save,
                                      wX = wX.save,
                                      wU = wU.save,
                                 verbose = FALSE)
                          )  )[c("lambda", "rho.MLE", "sigma.MLE", "lnProfileLike.FULL")]
            temp.eval <- get("capture.evaluations")
            assign("capture.evaluations", rbind(temp.eval, unlist(hold)), envir = capture.env)
                             return(hold$lnProfileLike.FULL)}
#    
# the try wrapper captures case when optim fails.   
            capture.env <- environment()
            look<- try(optimize( temp.fn, interval = llambda.start+c(-8,5),
                                   maximum= TRUE, tol=tol))
            evalSummary <- !(class( look)== "try-error")
            llambda.opt <- look$maximum   
            optim.counts <- nrow( capture.evaluations) + 2
            LKrigArgs$NtrA <- 20
            LKrigArgs$LKinfo$lambda<- exp(llambda.opt) 
            LKrigObject <- do.call("LKrig", c(LKrigArgs,
                                    list(use.cholesky = Mc.save,
                                                   wX = wX.save,
                                                   wU = wU.save))
                                   )                                                   
  }
###### end optimze block    
# save summary results from this set of parameters.
   out[ 1] <- LKrigObject$trA.est
   out[ 2] <- LKrigObject$lnProfileLike.FULL
   out[ 3] <- LKrigObject$GCV
   out[ 4] <- LKrigObject$sigma.MLE.FULL
   out[ 5] <- LKrigObject$rho.MLE.FULL
   out[ 6] <- llambda.opt
   out[ 7] <- LKrigObject$lnLike.FULL
   out[ 8] <- optim.counts
   out[ 9] <- NA
   return(list(summary = out,
                LKinfo = LKinfo,
         llambda.start = llambda.start,
            lambda.MLE =  exp(llambda.opt),
           lnLike.eval = capture.evaluations,
                  call = match.call(),
                    Mc = Mc.save,
                    wX = wX.save,
                    wU = wU.save )
          )
}

LKrigLatticeCenters <- function( object, ...){
  UseMethod("LKrigLatticeCenters")
}

LKrigLatticeCenters.default<- function( object,...){
   stop("LKgeometry  class needs to be specified")
 }

LKrigLatticeCenters.LKRectangle <- function( object, Level, ...){
     grid.list <- object$latticeInfo$grid[[ Level ]]
     centers   <- make.surface.grid( grid.list)
     return( centers)
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigNormalizeBasis <- function(LKinfo, Level, PHI, choleskyMemory = NULL,  ...) {
	# get  SAR matrix at level Level
	tempB <- LKrigSAR(LKinfo, Level = Level)
	tempB <- LKrig.spind2spam(tempB)
	# quadratic form involves applying inverse precision matrix to basis function evaluted at
	# locations for evaluation
wght <- LKrig.quadraticform(t(tempB) %*% tempB, PHI = PHI,
                     choleskyMemory = choleskyMemory)
	return(wght)
}


# hook for a model specific fast normalization 
LKrigNormalizeBasisFast <- function(LKinfo, ...) {
	UseMethod("LKrigNormalizeBasisFast")
}
LKrigNormalizeBasisFast.default <- function(LKinfo, ...) {
	stop("There is no default method for fast normalization")
}
# see 

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigSAR <- function(object,...){
  UseMethod("LKrigSAR")
}

LKrigSAR.default<- function( object, ...){
   stop("geometry for the SAR matrix not found")
 }

LKrigSAR.LKRectangle <- function( object, Level, ...){ 
  #function(mx, my, a.wght, stationary = TRUE, 
  # edge = FALSE, distance.type = "Euclidean") {
    # LatticeKrig  rectangular spatial autoregression (SAR)) is based on
    # a set of location centers
    # (also known as RBF nodes) to center the basis functions. This function
    # takes advantage of the centers being on a regular grid and equally spaced.
    # Thus the SAR weights applied to nearest neighbors can be generated from the
    # row and column indices of the lattice points.
    #
    # How exactly is the lattice laid out?  Indexing the lattice by a 2-d, regularly spaced array
    # it is assumed the indices are also the positions.
    # row index is the 'x' and column index is the 'y'
    # So  (1,1) is in the bottom left corner and (mx,nx) the top right.
    # This is of course  different than the usual way matrices are listed.
    # All directions for nearest neighbors use this 'location'
    # interpretation of the matrix indices i.e.  thinking of the indices
    # as the x and y coordinates  (1,2) is on _top_ of (1,1) -- not to the left.
    #
    # When the lattice is stacked as a vector of length m it is
    # done column by column -- the default stacking by applying the
    # 'c' operator to a matrix. The indexing for the stacked vector can be generated
    # in a simple way by  c( matrix( 1:(mx*my), mx,my)) and this is used in the
    # code below.
    #  To list the indices with the right spatial orientation to label as top, bottom, left and right,
    # use:  t(matrix( 1:(mx*my), mx,my))[my:1, ]
    
    ###############################################
    #    CONVENTIONS FOR FILLING IN PRECISION MATRIX
    ###############################################
    #  Note: Dimensions of a.wght determine
    #  how the precision matrix will be filled
    #  For each node in the MRF there are
    #  4 nearest neighbors and 4 additional second order
    # neighbors
    # labels for these connections are
    #   'NE'    'top'    'NW'
    #    'L'  'center'    'R'
    #   'SE'    'bot'    'SW'
    #
    #  indices for these elements are given by
    #  matrix(1:9, 3,3)
    #   1 4 7
    #   2 5 8
    #   3 6 9
    #  however, the way the function is coded
    #  the ordering is scrambled to be
    #  index<- c( 5,4,6,2,8,3,9,1,7)
    #  This seemingly disorganized order is from dealing with the center lattice point, then the
    #  the nearest neighbors and then adding the second order set.
    #
    #  when stationary is TRUE here is how precision matrix is filled:
    #
    #  length(a.wght)==1  just the center value is used with -1 as default for
    #  first order neighbors and 0 for second order
    #
    #  length(a.wght)==9  center value and all 8 neighbors as in diagram above
    #  order of the elements in this case is the same as stacking the 3 columns
    #  of 3X3 matrix. These are reordered below according to
    #  index<- c( 5,4,6,2,8,3,9,1,7)
    #
    #  when stationary is FALSE here is how precision matrix is filled:
    #
    #  if  a.wght depends on lattice position
    #  then dim(a.wght) should not be NULL and should have
    #  three dimensions with sizes mx,my and the third can have length
    #  1  or 9 depending on whether of the neighbor connections are
    #  specified.
    #
    ######################################################################
    #
   
    mx<-              object$latticeInfo$mx[Level]
    my<-              object$latticeInfo$my[Level]
    m<- mx*my
    #
    a.wght<- (object$a.wght)[[Level]]
    if( any(unlist(a.wght)<4) ){
        stop("a.wght less than 4")
      }
    stationary<-     attr( object$a.wght, "stationary")
    first.order<-    attr( object$a.wght, "first.order")
    distance.type <-  object$distance.type
    
    #  pass a.wght as an (mx by my)  matrix
    #  otherwise fill out matrix of this size with single value
    dim.a.wght <- dim(a.wght)
   
    # figure out if just a single a.wght or matrix is passed
    first.order <-  (( length(a.wght) == 1)|( length(dim.a.wght) == 2)) 
    # order of neighbors and center
    index <- c(5, 4, 6, 2, 8, 3, 9, 1, 7)
    # dimensions of precision matrix
    da <- as.integer(c(m, m))
    # contents of sparse matrix organize as a 3-dimensional array
    # with the last dimension indexing the weights for center and four nearest neighbors.
    if (first.order) {
        ra <- array(NA, c(mx, my, 5))
        ra[, , 1] <- a.wght
        ra[, , 2:5] <- -1
    }
    else {
        ra <- array(NA, c(mx, my, 9))
        for (kk in 1:9) {
   # Note that correct filling happens both as a scalar or as an mx X my matrix
            if (stationary) {
                ra[, , kk] <- a.wght[index[kk]]
            }
            else {
                ra[, , kk] <- a.wght[, , index[kk]]
            }
        }
    }
    #
    #  Order for 5 nonzero indices is: center, top, bottom, left right
    #  a superset of indices is used to make the arrays regular.
    #  and NAs are inserted for positions beyond lattice. e.g. top neighbor
    #  for a lattice point on the top edge. The NA pattern is also
    #  consistent with how the weight matrix is filled.
    #
    #  indices to use at left and right boundaries depend on if periodic boundary
    #  is specified (cylinder==TRUE)
    Bi <- rep(1:m, 5)
    i.c <- matrix(1:m, nrow = mx, ncol = my)
    # indices for center, top, bottom, left, right or ... N, S, E, W
    # NOTE that these are just shifts of the original matrix
    Bj <- c(i.c,
            LKrig.shift.matrix(i.c, 0, -1),
            LKrig.shift.matrix(i.c, 0,  1),
            LKrig.shift.matrix(i.c, 1,  0),
            LKrig.shift.matrix(i.c, -1, 0)
            )
    # indices for NW, SW, SE, SW
    if (!first.order) {
        Bi <- c(Bi, rep(1:m, 4))
        Bj <- c(Bj,
                   LKrig.shift.matrix(i.c,  1,  1),
                   LKrig.shift.matrix(i.c, -1,  1),
                   LKrig.shift.matrix(i.c,  1, -1),
                   LKrig.shift.matrix(i.c, -1, -1)
            )
    }
   
    # find all cases that are actually in lattice
    good <- !is.na(Bj)
    # remove cases that are beyond the lattice and coerce to integer
    # also reshape ra as a vector stacking the 9 columns
    #
    Bi <- as.integer(Bi[good])
    Bj <- as.integer(Bj[good])
    ra <- c(ra)[good]
    # return spind format because this is easier to accumulate
    # matrices at different multiresolution levels
    # see calling function LKrig.precision
    return(list(ind = cbind(Bi, Bj), ra = ra, da = da))
}



# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigSetup <- function(x = NULL,
                       nlevel=NULL, alpha=NA, nu = NULL, a.wght = NA,
                       normalize=TRUE,
                       lambda = NA, sigma = NA, rho = NA, rho.object = NULL,
                       latticeInfo=NULL, basisInfo=NULL, 
# default geometry is a rectangular domain with Euclidean distance                       
                       LKgeometry="LKRectangle",
# even if the geometry is different than rectangle many of the following defaults
# still are appropriate                       
                       distance.type="Euclidean",
# some natural defaults for the basis functions (including the default to be radial)                      
                       RadialBasisFunction = "WendlandFunction", overlap=2.5,                            
                       V=NA,
                       TensorBasisFunction = "WendlandTensorFunction",
                       BasisType= "Radial",
# some natural defaults for the fixed part of the model
                       fixedFunction="LKrigDefaultFixedFunction", fixedFunctionArgs = list( m=2),
# defaults for sparse matrix size.                        
                       max.points=NULL, mean.neighbor=50, choleskyMemory=NULL,
# useful for debugging                       
                       verbose = FALSE, noCheck=FALSE,
# these additional arguments will just be added as a list to the LKinfo object as setupArgs
                       setupArgs=NULL, ...) { 
#
# create initial shell of LKinfo object with classes and common parameters
   setupArgs<- c( setupArgs, list( ...))
  	
   LKinfo<-  list( nlevel = nlevel,
                    alpha = alpha,
                   a.wght = a.wght,
                       nu = nu,
                normalize = normalize,
                   lambda = lambda,
                    sigma = sigma,
                      rho = rho,
               rho.object = rho.object,
            distance.type = distance.type,   
              latticeInfo = latticeInfo,
                setupArgs = setupArgs,
            fixedFunction = fixedFunction,
        fixedFunctionArgs = fixedFunctionArgs,
           choleskyMemory = choleskyMemory 
                 ) 
  #   add information for basis functions 
    LKinfo$basisInfo<- c( basisInfo,
                         list(           BasisType = BasisType,
                               RadialBasisFunction = RadialBasisFunction,
                               TensorBasisFunction = TensorBasisFunction,
                                           overlap = overlap,
                                        max.points = NULL,
                                     mean.neighbor = mean.neighbor,
                                                 V = V
                              )
                         )  
# set the geometry class -- this will determine what
# functions are applied below in the "Setup" calls
   class(LKinfo) <- c( "LKinfo", LKgeometry)

# the next function is in the case    
   LKinfo<- setDefaultsLKinfo( LKinfo )
   if( verbose){
     temp<- LKinfo
     class( temp) <- NULL
     print( as.list(temp))
   }
#    
# Create information to construct the lattice at each level based on the
# geometry of spatial domain, number of levels, and the data locations
# this function is overloaded and is determine by LKgeometry
# Note that extra arguments given to LKrigSetup are passed through to
# this function setting up lattice.
# there is no default method
# conceptually the following call is jsut LKrigSetupLattice( LKinfo, x, verbose, ...)
# but this does not work because the additional arguments in list( ...) are handled
#  
   latticeInfo<- do.call( "LKrigSetupLattice",
                 c(list( object=LKinfo, x=x, verbose=verbose), setupArgs) ) 
   LKinfo$latticeInfo<-  c(LKinfo$latticeInfo, latticeInfo)
#
# reformat, modify, and check the parameters for the Markox random field/ GP model
#  fix up the alpha parameters
#   the default method is probably adequate for most geometries and SARs
      LKinfo$alpha<- LKrigSetupAlpha(LKinfo)
      if( verbose){
        print(alpha)}
# fix up the a.wght parameters specfic geometries might need 
# a specific function here. 
      LKinfo$a.wght<-LKrigSetupAwght(LKinfo)
# set lambda if sigma and rho are passed.
    if (is.na(lambda[1])) {
        lambda <- sigma^2/rho
        LKinfo$lambda<- lambda
    }  
# Note saving call argument in return allows the function to be re evaluated
   LKinfo$call<- match.call()
# Finally make some generic checks that all basic components of
# LKinfo class are included
   if( !noCheck){
    LKinfoCheck(LKinfo)
  }
   return(LKinfo)
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigSetupAlpha <- function(object, ...){
  UseMethod("LKrigSetupAlpha")
}

LKrigSetupAlpha.default<- function( object, ...){
   alpha <- object$alpha
   nlevel <- object$nlevel
# some obvious defaults for alpha to simplify calls from LatticeKrig or LKrig.   
   if( is.na(alpha[1]) ) {
       if( nlevel==1){
          alpha<- 1.0
        }
       else{
          alpha<- rep( NA, nlevel)
        }
    }
    scalar.alpha <- !is.list(alpha) 
    if (scalar.alpha & (nlevel != 1) & (length(alpha) == 1)){
                stop( "Only one alpha specifed for multiple levels")}     
# coerce alpha to a list if it is passed as something else
    if (!is.list(alpha)) {
        alpha <- as.list(alpha)
    }
    return( alpha )
 }




# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrigSetupAwght <- function(object,...){
  UseMethod("LKrigSetupAwght")
}

LKrigSetupAwght.default<- function( object,...){
# object == LKinfo  
   a.wght<- object$a.wght
  nlevel<- object$nlevel
  if (!is.list(a.wght)) {
        # some checks on a.wght
        # coerce a.wght to list if it is passed as something
        # else (most likely a vector)
        if (nlevel == 1) {
            a.wght <- list(a.wght)
        }
        else {
            # repeat a.wght to fill out for all levels.
            if (length(a.wght) == 1) {
                a.wght <- rep(a.wght, nlevel)
            }
            a.wght <- as.list(c(a.wght))
        }
    }
   # check length of a.wght list
    if (length(a.wght) != nlevel) {
        stop("length of a.wght list differs than of nlevel")
    }
# default is to use the usual cholesky based normalization    
# see LKRectangle for an example of something different.
     attr( a.wght, "fastNormalize") <- FALSE
     return(a.wght)
 }
LKrigSetupLattice <- function(object, ...){
  UseMethod("LKrigSetupLattice")
}

LKrigSetupLattice.default<- function( object,...){
   stop("LKgeometry needs to be specified")
 }

LKrigUnrollZGrid<- function( grid.list, ZGrid=NULL){
  if( is.null(ZGrid)){
    return(ZGrid)
  }
  if( is.list( ZGrid) ){
     if( any(grid.list[[1]] != ZGrid[[1]]) |any(grid.list[[2]] != ZGrid[[2]]) ){
         stop("grid list does not match grid for covariates")
       }  
# wipe out the x and y components of ZGrid
  ZGrid<- ZGrid$z
  }
# check dimensions
    Zdim<- dim( ZGrid)
      nx<- length( grid.list[[1]])
      ny<- length( grid.list[[2]])
      if( (Zdim[1] != nx) | (Zdim[2] != ny) ){
         stop( "Dimension of ZGrid does not match dimensions of location grid list.")
      }
# reshape as a matrix where rows index locations.
# Note that this works whether Zdim[3] exists or not! 
      return( matrix( c(ZGrid),  nrow= Zdim[1]*Zdim[2] ))
 }
  
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

LatticeKrig<- function(x, y, Z=NULL,  nlevel=4,  
                        LKinfo=NULL, na.rm=TRUE,
                        tol=.005, verbose=FALSE, ...){
  # a crisp wrapper where many default values are exercised.
              x<- as.matrix(x)
              ind<- is.na(y)
              if( any(ind)){
                if( na.rm){
                  x<- x[!ind,]
                  y<- y[!ind]
                  warning("NAs removed")
                  if( !is.null(Z)){
                    Z<- as.matrix( Z)[!ind,]
                  }
                 }
                 else{
                   stop("NAs in y")
                 }
              }
#      	                     
            if( is.null(LKinfo) ){
            argList<-list( ...)
# determine the geometry/dimension if not specified
# set up some thin plate spline like default models for just Euclidean spatial domains
# in 1,2 and 3 dimensions.              
            argList<- LatticeKrigEasyDefaults(argList,nlevel,x)
            if(verbose){
              cat("extra args:", fill=TRUE)
              print( argList)
            }
              LKinfo<- do.call( "LKrigSetup", c( list( x=x,  nlevel=nlevel,
                                     verbose=verbose), argList ) )
            }    
 # find lambda   
              obj<- LKrigFindLambda( x=x,y=y, Z=Z, LKinfo=LKinfo, tol=tol)
              if( verbose){
              	print( obj$summary)
              }
              LKinfo$lambda <- obj$lambda.MLE
              obj2<- c(  LKrig( x,y,Z=Z, LKinfo=LKinfo), list(MLE= obj) )             
              class( obj2)<- c( "LKrig", "LatticeKrig")
              return( obj2)
            }

LatticeKrigEasyDefaults<- function( argList,nlevel,x){
	  if( is.null(argList$LKgeometry) ){
                xDimension<- ncol( x)
                argList$LKgeometry<- c( "LKInterval", "LKRectangle", "LKBox")[xDimension]
                NC<- argList$NC      
                if( is.null(NC)){
                  N<- nrow(x)
                  a<-  sum(  2^(xDimension*(0:(nlevel-1)))  )
                  NCtest<-  (N/a)^( 1/xDimension)            
# NC chosen so that with  d= xDimensison   NCtest^d * ( 1 + 2^d  + 2^(2d) + ...)
#  gives a basis size that is at least the number of observations.
# Note that if NC.buffer is not zero this can still add quite few extra basis function 
# outside the domain. 
                  argList$NC<- round(max(4, NCtest ))
               }
                if( is.null(argList$a.wght)){
              	  # a thinplate spline-like a.wght
                  argList$a.wght<- 2*xDimension +.01
                }
                if( is.null(argList$nu)){
                	argList$nu<-1
                	}
              }
              return( argList)
}
## LKrig model for 3-d data in a box
#
setDefaultsLKinfo.LKBox<- function( object, ...)
  {
    # object == LKinfo
  if( is.null(object$setArgs$NC) ){
    object$setupArgs$NC<- 5
    object$setupArgs$NC.buffer<- 2
  }
  if( is.null( object$setupArgs$a.wght) ){
      object$setupArgs$a.wght<- 6.01
    }
  return( object)
  }

LKrigSetupLattice.LKBox <- function(object, x, verbose,
                                       NC, NC.buffer=5, grid.info=NULL, ...){
#object is usually of class LKinfo
  rangeLocations<-  apply(x, 2, "range")
  if( ncol( x) !=3) {
       stop( "x is not 3-d !")
   }
  if( is.null( grid.info)){
    grid.info<-list( range= rangeLocations )
    }  
  nlevel<- object$nlevel
  delta.level1<- max(grid.info$range[2,] - grid.info$range[1,]) /( NC - 1 )
  mx<- mxDomain<- matrix( NA, ncol = 3, nrow= nlevel)
  mLevel<- rep( NA, nlevel)
  delta.save<- rep( NA, nlevel)
  grid.all.levels<- NULL
# begin multiresolution loop 
   for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width <- NC.buffer * delta
  # NOTE delta distance of lattice is the same in all dimensions      
        grid.list <- list( x1= seq(grid.info$range[1,1] - buffer.width, 
                                   grid.info$range[2,1] + buffer.width, delta),
                           x2= seq(grid.info$range[1,2] - buffer.width, 
                                   grid.info$range[2,2] + buffer.width, delta),
                           x3= seq(grid.info$range[1,3] - buffer.width, 
                                   grid.info$range[2,3] + buffer.width, delta)       
                                    )
        mx[j,] <- unlist(lapply(grid.list, "length"))
        mxDomain[j,]<- mx[j,] - 2*NC.buffer
        mLevel[j]<- prod( mx[j,])
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
# end multiresolution level loop
# create a useful index that indicates where each level starts in a
# stacked vector of the basis function coefficients.
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (mLevel - 2 * NC.buffer)
    out<-  list(
# required arguments for latticeInfo  
      m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
# specific arguments for LKBox Geometry            
                  mx = mx, mLevelDomain = mLevelDomain, mxDomain = mxDomain, 
                  NC = NC,
                  NC.buffer = NC.buffer,
                  grid = grid.all.levels)
 return( out )
}

LKinfo<- list( latticeInfo= list( mLevel=60, mx=rbind( c(4,3,5) )), a.wght= list( 6.5) ) 

LKrigSAR.LKBox<- function(object, Level,...){
   m<- object$latticeInfo$mLevel[Level] 
   a.wght<- (object$a.wght)[[Level]]
   if( length(a.wght) > 1) {
     stop("a.wght must be constant")
   }
   da<- c( m,m)
   # INTIALLY create all arrays for indices ignoring boudaries
   #  e.g. an edge really only has 2 or 3 neighbors not 4.
   ra<- c(rep( a.wght, m), rep( -1, m*6) )
   Bi <-  c( rep( 1:m,7))
   Bindex<- array( 1:m, object$latticeInfo$mx[Level,])
  # indexing is East, West, South, North, Down, Up.
   Bj<- c( 1:m, 
       c(LKArrayShift(Bindex, c(-1, 0, 0) ) ), 
       c(LKArrayShift(Bindex, c( 1, 0, 0) ) ), 
       c(LKArrayShift(Bindex, c( 0,-1, 0) ) ), 
       c(LKArrayShift(Bindex, c( 0, 1, 0) ) ),
       c(LKArrayShift(Bindex, c( 0, 0,-1) ) ), 
       c(LKArrayShift(Bindex, c( 0, 0, 1) ) )
   )  
   inRange<- !is.na( Bj)
   Bi<- Bi[inRange]
   Bj<- Bj[inRange]
     ra<- ra[inRange]
  return(list(ind = cbind(Bi, Bj), ra = ra, da = da)) 
}  

LKrigLatticeCenters.LKBox<- function(object, Level,...){
   gridl<- object$latticeInfo$grid[[Level]]
   return( as.matrix(expand.grid( gridl)) )
} 










## LKrig model for 1-d data on an interval



LKrigSetupLattice.LKInterval <- function(object, x, verbose,
                                       NC, NC.buffer=5, grid.info=NULL, ...){
#object is usually of class LKinfo
  rangeLocations<-  range(x)
  if( ncol( x) !=1) {
       stop( "x is not 1-d !")
   }
  if( is.null( grid.info)){
    grid.info<-list( xmin=  rangeLocations[1], xmax= rangeLocations[2])
}  
  nlevel<- object$nlevel
  delta.level1<- ( grid.info$xmax - grid.info$xmin ) /( NC - 1 )
  mLevel<- rep( NA, nlevel)
  delta.save<- rep( NA, nlevel)
  grid.all.levels<- NULL
# begin multiresolution loop 
   for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width <- NC.buffer * delta
        grid.list <- list(x = seq(grid.info$xmin - buffer.width, 
            grid.info$xmax + buffer.width, delta) )
        mLevel[j] <- length(grid.list$x)
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
# end multiresolution level loop
# create a useful index that indicates where each level starts in a
# stacked vector of the basis function coefficients.
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (m - 2 * NC)
    out<-  list(  m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
  # specific arguments for LKInterval              
                  mLevelDomain = mLevelDomain,
                  NC=NC,
                  NC.buffer = NC.buffer,
                  grid = grid.all.levels)
 return( out )
}



LKrigSAR.LKInterval<- function(object, Level, ... ){
   m<- object$latticeInfo$mLevel[Level] 
   a.wght<- (object$a.wght)[[Level]]
   if( length(a.wght) > 1) {
     stop("a.wght must be constant")
   }
   da<- c( m,m)
   ra<- c(rep( a.wght, m), rep( -1, (m-1)), rep( -1, (m-1)) )
   Bi <-  c( 1:m,2:m, 1:(m-1))
   Bj<- c( 1:m, 1:(m-1), 2:m)
  return(list(ind = cbind(Bi, Bj), ra = ra, da = da)) 
}  

LKrigLatticeCenters.LKInterval<- function(object, Level, ... ){
   gridl<- object$latticeInfo$grid[[Level]]
   return( matrix( gridl$x, ncol=1) )
} 


LKrigSetupAlpha.LKInterval <- function( object, ... ){
  LKrigSetupAlpha.LKRectangle(object)
  }
  # LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2


setDefaultsLKinfo.LKRectangle <- function(object,...)
  {
  	if( is.na(object$basisInfo$V)){
  		object$basisInfo$V <- diag( rep(1,2))
  	}
    return(object)
  }
  
LKrigSetupLattice.LKRectangle <- function(object, x, verbose,                                         
                                          NC=NULL, NC.buffer=5, grid.info=NULL,
                                          ... ){
###### some common setup opertations to all geometries
  LKinfo<- object
  if(  class( LKinfo)[1] != "LKinfo") {
    stop("object needs to an LKinfo object")
  }
  rangeLocations<- apply( x,2, "range")
  nlevel<- LKinfo$nlevel
###### end common operations  
  
   if (is.null(NC)) {
      stop("Need to specify NC for grid size")
        }
#  if ( LKinfo$distance.type!= "Euclidean" ) {
#        stop("distance type is not supported (or is misspelled!).")        
#     }
# if lattice information is missing create grid based on the locations
   if (is.null(grid.info)) {
        # find range of scaled locations
        range.x <- apply(as.matrix(x) %*% t(solve(LKinfo$basisInfo$V)),
                               2, "range")
        if (verbose) {
            cat("ranges of transformed variables", range.x, fill = TRUE)
        }
        grid.info <- list(xmin = range.x[1, 1], xmax = range.x[2, 
            1], ymin = range.x[1, 2], ymax = range.x[2, 2])
    }
# set the largest spacing of centers if not given in grid.info    
    if( is.null(grid.info$delta)){        
        d1 <- grid.info$xmax - grid.info$xmin
        d2 <- grid.info$ymax - grid.info$ymin
        grid.info$delta <-  max(c(d1, d2))/(NC - 1)
    }
    #
    # actual number of grid points is determined by the spacing delta
    # delta is used so that centers are equally
    # spaced in both axes and NC is the maximum number of grid points
    # along the larger range. So for a rectangular region
    # along the longer side there will be NC grid points but for the shorter dimension
    # there will be less than NC.
    # Finally note that if NC.buffer is greater than zero the number of grid points in
    # both dimensions will be increased by this buffer around the edges:
    # A total of  NC + 2* NC.buffer grid points along the longer dimension
    #
    delta.level1 <- grid.info$delta
    delta.save <- mx <- my <- rep(NA, nlevel)
    #
    # build up series of nlevel multi-resolution grids
    # and accumulate these in a master list -- creatively called grid
    grid.all.levels <- NULL
    # loop through multiresolution levels decreasing delta by factor of 2
    # and compute number of grid points.
    # build in a hook for buffer regions to differ in x and y
    NC.buffer.x <- NC.buffer
    NC.buffer.y <- NC.buffer
    for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width.x <- NC.buffer.x * delta
        buffer.width.y <- NC.buffer.y * delta 
        # rectangular case
        grid.list <- list(x = seq(grid.info$xmin - buffer.width.x, 
            grid.info$xmax + buffer.width.x, delta), y = seq(grid.info$ymin - 
            buffer.width.y, grid.info$ymax + buffer.width.y, 
            delta))
        mx[j] <- length(grid.list$x)
        my[j] <- length(grid.list$y)
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
    # end multiresolution level loop
    # create a useful index that indicates where each level starts in a
    # stacked vector of the basis function coefficients.
    mLevel<- mx*my
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (mx - 2 * NC.buffer.x) * (my - 2 * NC.buffer.y)
  # first five components are used in the print function and
  # should always be created.
  # The remaining compoents are specific to this geometry.
    out<-  list(  m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
  # specific arguments for LKrectangle              
                  mLevelDomain = mLevelDomain,
                  mx = mx, my = my, 
                  NC.buffer.x = NC.buffer.x, NC.buffer.y = NC.buffer.y,  
                  grid = grid.all.levels, grid.info=grid.info
                 )

 return( out ) 
  }  
  

LKrigSetupAlpha.LKRectangle <- function( object, ... ){
   alpha <- object$alpha
   nlevel <- object$nlevel
   nu<- object$nu
   if( is.na(alpha[1]) ) {
        alpha<- rep( NA, nlevel)
    }
    scalar.alpha <- !is.list(alpha) | !is.null(nu)
# determine alpha if nu has been specified
    if (!is.null(nu)) {
        alpha <- exp(-2 * (1:nlevel) * nu)
        alpha <- alpha/sum(alpha)
    }
    if (scalar.alpha & (nlevel != 1) & (length(alpha) == 1)){
                stop( "Only one alpha specifed for multiple levels")}     
# coerce alpha to a list if it is passed as something else
    if (!is.list(alpha)) {
        alpha <- as.list(alpha)
    }
    return( alpha )
  }
  
LKrigSetupAwght.LKRectangle <- function( object, ... ){ 
# the object here should be of class LKinfo	
  a.wght<- object$a.wght
  nlevel<- object$nlevel
  mx<- object$latticeInfo$mx
  my<- object$latticeInfo$my
  if (!is.list(a.wght)) {
        # some checks on a.wght
        # coerce a.wght to list if it is passed as something
        # else (most likely a vector)
        if (nlevel == 1) {
            a.wght <- list(a.wght)
        }
        else {
            # repeat a.wght to fill out for all levels.
            if (length(a.wght) == 1) {
                a.wght <- rep(a.wght, nlevel)
            }
            a.wght <- as.list(c(a.wght))
        }
    }
   # check length of a.wght list
    if (length(a.wght) != nlevel) {
        stop("length of a.wght list differs than of nlevel")
    }
    #################################
    # rest of function determines the type of model
    # setting logicals for stationary, first.order and
    # fastnormalization
    #
    # now figure out if the model is stationary
    # i.e. a.wght pattern is to be  repeated for each node
    # at a given level this is the usual case
    # if not stationary a.wght should be a list of arrays that
    # give values for each node separately
    stationary <- is.null(dim(a.wght[[1]]))
    first.order<- rep( NA, nlevel)
    # simple check on sizes of arrays
    if (stationary) {      
        for (k in 1:length(a.wght)) {
             N.a.wght <- length(a.wght[[1]])
        # allowed lengths for a.wght are just the center 1 values
        # or 9 values for center,  first, and second order neighbors
         if (is.na(match(N.a.wght, c(1, 9)))) {
               stop("a.wght needs to be of length 1 or 9")
        }
           first.order[k]<- ifelse( N.a.wght == 1, TRUE, FALSE)
        }
    }
    else {
        for (k in 1:length(a.wght)) {
            dim.a.wght <- dim(a.wght[[k]])
            if( (dim.a.wght[1] != mx[k]) | (dim.a.wght[2] != my[k]) ) {
                stop(paste(
                    "a.wght matrix at level ", k,
                    " has wrong first two dimensions:", dim.a.wght,
                    " compare to lattice ", mx[k], my[k] ) )
            }
        first.order[k] <- length( dim.a.wght) == 2
        }
     }  
#   
    RBF<- object$basisInfo$RadialBasisFunction 
    fastNormalization <- stationary & 
            all( first.order ) & all( !is.na( unlist( a.wght) ) ) &
             (RBF=="WendlandFunction") 
#NOTE current code is hard wired for Wendland 2 2 RBF  
    if(fastNormalization){
        attr( a.wght, which="fastNormDecomp")<-
           LKRectangleSetupNormalization( mx, my, a.wght)
           }
 # 
    attr( a.wght, which="fastNormalize") <- fastNormalization 
    attr( a.wght, which="first.order") <- first.order
    attr( a.wght, which="stationary") <- stationary
#
  return(a.wght)
  }
     
LKRectangleSetupNormalization<- function(mx,my, a.wght){
  out<- list()
  nlevel<- length( a.wght)
# coerce a.wght from a list with scalar components back to a vector
  a.wght<- unlist( a.wght)
   
  for ( l in 1:nlevel){	
  	  mxl<- mx[l]
   myl<- my[l]
  Ax<- diag( a.wght[l]/2, mxl)
  Ax[  cbind( 2:mxl, 1:(mxl-1)) ] <- -1
  Ax[  cbind( 1:(mxl-1), 2:mxl) ] <- -1
# 
  Ay<- diag( a.wght[l]/2, myl)
  Ay[  cbind( 2:myl, 1:(myl-1)) ] <- -1
  Ay[  cbind( 1:(myl-1), 2:myl) ] <- -1
  eigen( Ax, symmetric=TRUE) -> hold
  Ux<- hold$vectors
  Dx<- hold$values
  eigen( Ay, symmetric=TRUE) -> hold
  Uy<- hold$vectors
  Dy<- hold$values
 # extra list makes out a list where each component is itself a list  
  out<- c(out, list( list( Ux=Ux, Uy=Uy, Dx=Dx, Dy=Dy ) ) )
  }
  return(out)
 }

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

Radial.basis <- function(x1, centers, basis.delta,
                     max.points = NULL, 
                  mean.neighbor = 50,
            RadialBasisFunction = "WendlandFunction", 
                  distance.type = "Euclidean")
{    
    d <- ncol(x1)
    n1 <- nrow(x1)
    n2 <- nrow(centers)
    if (is.null(max.points)) {
        Nmax <- n1 * mean.neighbor
    }
    else {
        Nmax <- max.points
    }
    # evalute RBF basis functions at the x1 locations with
    # nodes given by centers. Returned is a sparse matrix in
    # a simpler format than spam  (row/column indices and value)
    # returned values ind and rd below in 'out' object.  
    out<- LKDistance( x1, centers,
                             delta =  basis.delta,
                        max.points = max.points,
                     mean.neighbor = mean.neighbor,
                     distance.type = distance.type)
                    
    # evaluate distance  with RBF ---  usually Wendland2.2   
    out$ra <- do.call(RadialBasisFunction, list(d = out$ra/basis.delta) )
    out <- LKrig.spind2spam(out)
    return(out)
}

WendlandFunction <- function(d) {
    # dimension =2 k =2
    if (any(d < 0)) 
        stop("d must be nonnegative")
    return(((1 - d)^6 * (35 * d^2 + 18 * d + 3))/3 * (d < 1))
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

Tensor.basis <- function(x1, centers, basis.delta,
                     max.points = NULL, 
                  mean.neighbor = 50,
            TensorBasisFunction = "WendlandTensorFunction", 
                  distance.type = "Euclidean")
{    
    d <- ncol(x1)
    n1 <- nrow(x1)
    n2 <- nrow(centers)
    if (is.null(max.points)) {
        Nmax <- n1 * mean.neighbor
    }
    else {
        Nmax <- max.points
    }
    # evalute RBF basis functions at the x1 locations with
    # nodes given by centers. Returned is a list following the 
    # spind format but with a matrix in place of the vector of nonzero
    # matrix values 
    # This format is because a distance is required for each component
    # to evaluate the tensor product basis function
    out<- LKDistanceComponents( x1, centers,
                             delta =  basis.delta,
                        max.points = max.points,
                     mean.neighbor = mean.neighbor,
                     distance.type = distance.type)
                     
    # evaluate distance  with RBF ---  usually Wendland2.2 
    # in this case ra is a matrix with each row being the componentwise
    # distances and with the maximum distance in any coordinate being less than
    # basis.delta.   
    out$ra <- do.call(TensorBasisFunction, list(d = out$ra/basis.delta) )    
    out <- LKrig.spind2spam(out)
    return(out)
}

WendlandTensorFunction <- function(d){
# product of Wendland 2.2 in each coordinate
	if (!is.matrix(d)) {
		stop("d must be a matrix")
	}
	if (any(d < 0)) {
		stop("d must be nonnegative")
	}
	nCol <- ncol(d)
# this is not as efficient as possible but it should be clear  what is
# being computed ...
	temp <-                ((1 - d[, 1])^6 * (35 * d[, 1]^2 + 18 * d[, 1] + 3))/3 *
	                            (d[, 1] < 1)
	if (nCol > 1) {
		for (j in (2:nCol)) {
			temp <- temp * ((1 - d[, j])^6 * (35 * d[, j]^2 + 18 * d[, j] + 3))/3 * 
				                (d[, j] < 1)
		}
	}
	return(temp)
}
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

predict.LKrig <- function(object, xnew = object$x, Znew = NULL, 
    drop.Z = FALSE,return.levels=FALSE, ...) {
  #
    if( !drop.Z & is.null(Znew)){
      Znew<- object$Z
    }
    if( !is.null( object$LKinfo$fixedFunction)){
        temp1<- predictLKrigFixedFunction(object, xnew = xnew, Znew = Znew, 
                   drop.Z = drop.Z)
      }
    else{
       temp1<-rep(0, nrow(xnew))
    }
    PHIg <- LKrig.basis(xnew, object$LKinfo)
# the nonparametric component from the spatial process
# described by the multiresolution basis
  if( !return.levels){
    temp2 <- PHIg %*% object$c.coef
    return(temp1 + temp2)
  }  
  else{
    nLevels<- object$LKinfo$nlevel
    temp2<- matrix( NA, ncol=nLevels, nrow= nrow( xnew))
    for( level in 1:nLevels){
# indices for each multiresolution level      
       startLevel<- object$LKinfo$offset[level] +1
       endLevel<-  object$LKinfo$offset[level+1]
       indexLevel<- startLevel : endLevel
       temp2[,level]<- PHIg[,indexLevel] %*% object$c.coef[indexLevel,]
    }
    return( cbind(temp1,temp2))
  }
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2
predictLKrigFixedFunction <- function(object, xnew=NULL, Znew = NULL, drop.Z = FALSE){
     if( is.null(xnew)){
       xnew<- object$x
     }
# predictions for fixed part of the model
# and can be with or without the additional covariates, Znew.
     distance.type<- object$LKinfo$distance.type
     T.matrix<- do.call(object$LKinfo$fixedFunction, c(
                             list(x = xnew, Z = Znew,
                                  distance.type = distance.type),
                                  object$LKinfo$fixedFunctionArgs))
    if( !drop.Z){
     temp1<- T.matrix%*%object$d.coef}
    else{
     temp1<- T.matrix%*%object$d.coef[object$ind.drift, ]
    }
    return( temp1)
  }


# fields, Tools for spatial data
# Copyright 2004-2009, Institute for Mathematics Applied to Geosciences
# University Corporation for Atmospheric Research
# Licensed under the GPL -- www.gpl.org/licenses/gpl.html
"predictSE.LKrig" <- function(object, xnew = object$x, 
    Znew = object$Z, verbose = FALSE, ...) {
    if (is.null(object$Mc)) {
        stop("need to include the sparse cholesky decompostion in LKrig object \r\nin calling LKrig set return.cholesky = TRUE")
    }
    if(is.null(object$LKinfo$fixedFunction)){
      stop("Standard errors not supported with out a fixed component")
    }
    # set some local variables
    NG <- nrow(xnew)
    lambda <- object$lambda
    rho <- object$rho.MLE
    sigma2 <- lambda * rho
    weights <- object$weights
    LKinfo <- object$LKinfo
    # figure out if extra covariates should be included
    # and build fixed effects matrices
    # (ind.drift has the indices of just the spatial drift part --- e.g. the linear polynomial)
    if ( is.null(Znew) & (object$nZ > 0) ) {
        Znew <- object$Z
    }
    distance.type<- LKinfo$distance.type
    T.matrix <-do.call(object$LKinfo$fixedFunction, c(
                                  list( x=object$x, Z=object$Z, distance.type = distance.type),
                                  object$LKinfo$fixedFunctionArgs))
    t0 <- t(do.call(object$LKinfo$fixedFunction, c(
                                  list( x=xnew,     Z=Znew,     distance.type = distance.type),
                                  object$LKinfo$fixedFunctionArgs) ))
    Omega <- object$Omega
    #
    k0 <- LKrig.cov(object$x, xnew, LKinfo = LKinfo)
    wS <- diag.spam(sqrt(weights))
    PHI <- LKrig.basis(object$x, LKinfo)
    hold <- LKrig.coef(object$Mc, wS %*% LKrig.basis(object$x, LKinfo),
                     sqrt(weights) * T.matrix, sqrt(weights) * k0, lambda, weights)
    # version of 'c'coefficents for usual Kriging model
    #    c.mKrig<-  weights*(k0 - T.matrix%*%hold$d.coef - PHI%*%hold$c.coef)/ lambda
        d.coef <- hold$d.coef
    # colSums used to find multiple quadratic forms  e.g.  diag(t(x) %*%A%*%x) == colSums( x* (A%*%(x)))
    temp1<-  rho * (colSums(t0*(Omega %*% t0)) - 2*colSums(t0*d.coef))
 # find marginal variances -- trival in the stationary case!
    temp0 <- rho *  (LKrig.cov( xnew, LKinfo=LKinfo, marginal=TRUE) -
   colSums(k0*hold$c.mKrig))
 # Add marginal variance to part from estimate
    temp <- temp0 + temp1
    return(sqrt(temp))
}
# fields, Tools for spatial data
# Copyright 2004-2013, Institute for Mathematics Applied Geosciences
# University Corporation for Atmospheric Research
# Licensed under the GPL -- www.gpl.org/licenses/gpl.html


"predictSurface.LKrig" <- function(object, grid.list = NULL, 
       extrap = FALSE, chull.mask = NA, nx = 80, ny = 80,
       xy = c(1,2),  verbose = FALSE, ZGrid=NULL, drop.Z= FALSE, ...) {
    # NOTE: 
    # without grid.list
    # default is 80X80 grid on first two variables
    # rest are set to median value of x.
    if( is.null(ZGrid) & !drop.Z & (!is.null(object$Z)) ) {
      stop("need to specify covariate values or set drop.Z==TRUE")
    }
# create a default grid if it is not passed    
    if (is.null(grid.list)) {
        grid.list <- fields.x.to.grid(object$x, nx = nx, ny = ny, 
            xy = xy)
    }
# do some checks on Zgrid and also reshape as a matrix
# rows index grid locations and columns the covariates (like Z in predict).
    Z<- LKrigUnrollZGrid( grid.list, ZGrid)  
# here is the heavy lifting
    xg <- make.surface.grid(grid.list)
# NOTE: the predict function called will need to do some internal  the checks
# whether the evaluation of a large number of grid points (xg)  makes sense.
    out<-  predict(object, xg, Znew=Z, drop.Z= drop.Z, ...)
# reshape as list with x, y and z components    
    out <-  as.surface( xg, out )
    #
    # if extrapolate is FALSE set all values outside convex hull to NA
    if (!extrap) {
        if( is.null( object$x)){
          stop("need and x matrix in object")
        }
        if (is.na(chull.mask)) {
            chull.mask <- unique.matrix(object$x[, xy])
        }
        out$z[!in.poly(xg[, xy], xp = chull.mask, convex.hull = TRUE)] <- NA
    }
    #
    return(out)
}
print.LKinfo <- function(x, ...) {
    LKinfo <- x
    L <- LKinfo$nlevel
    cat("Classes for this object are: " , class( LKinfo), fill=TRUE)
    cat("Ranges of locations in raw scale:", fill=TRUE)
    print(  LKinfo$latticeInfo$rangeLocations)
    cat(" ", fill = TRUE)
    cat("Number of levels:", L, fill = TRUE)
    cat("delta scalings:", x$latticeInfo$delta, fill = TRUE)
    cat("with an overlap parameter of ", LKinfo$basisInfo$overlap, fill=TRUE)
    cat("alpha: ", unlist(x$alpha), fill = TRUE)
    if (!is.null(x$nu)) {
        cat("based on smoothness nu = ", x$nu, fill = TRUE)
    }
    cat("a.wght: ", unlist(x$a.wght), fill = TRUE)
       cat(" ", fill = TRUE)
    cat("Distance type: ", LKinfo$distance.type, fill = TRUE)
        cat(" ", fill = TRUE)
      temp<- cbind( 1:L, LKinfo$latticeInfo$mLevel)
      dimnames( temp)<- list( rep( "", L), c("Level" ,   "Basis size"))
      print( temp)
      cat("Total basis functions ",  LKinfo$latticeInfo$m, fill=TRUE)
# Details on basis functions at each level
        if( LKinfo$normalize){
        cat("Basis functions will be normalized to approximate stationarity", fill=TRUE)
        }
        cat(" ", fill = TRUE)   
}



# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

print.LKrig <- function(x, digits = 4, ...) {
    LKinfo <- x$LKinfo
    if (is.matrix(x$residuals)) {
        n <- nrow(x$residuals)
        NData <- ncol(x$residuals)
    }
    else {
        n <- length(x$residuals)
        NData <- 1
    }
    c1 <- "Number of Observations:"
    c2 <- n
    if (NData > 1) {
        c1 <- c(c1, "Number of data sets fit:")
        c2 <- c(c2, NData)
    }
    c1 <- c(c1, "Number of parameters in the fixed component")
    c2 <- c(c2, x$nt)
    if (x$nZ > 0) {
        c1 <- c(c1, "Number of covariates")
        c2 <- c(c2, x$nZ)
    }
    if (!is.na(x$eff.df)) {
        c1 <- c(c1, " Effective degrees of freedom (EDF)")
        c2 <- c(c2, signif(x$eff.df, digits))
        c1 <- c(c1, "   Standard Error of EDF estimate: ")
        c2 <- c(c2, signif(x$trA.SE, digits))
    }
    c1 <- c(c1, "Smoothing parameter (lambda)")
    c2 <- c(c2, signif(x$lambda, digits))
    if (NData == 1) {
        c1 <- c(c1, "MLE sigma ")
        c2 <- c(c2, signif(x$shat.MLE, digits))
        c1 <- c(c1, "MLE rho")
        c2 <- c(c2, signif(x$rho.MLE, digits))
    }
    c1 <- c(c1, "Nonzero entries in Ridge regression matrix")
    c2 <- c(c2, x$nonzero.entries)
    sum <- cbind(c1, c2)
    dimnames(sum) <- list(rep("", dim(sum)[1]), rep("", dim(sum)[2]))
    cat("Call:\n")
    dput(x$call)
    print(sum, quote = FALSE)
    cat(" ", fill = TRUE)
#    
    if( is.null( x$LKinfo$fixedFunction)){  
        cat("No fixed part of model", fill = TRUE)
    }
    else{
      
        if( x$LKinfo$fixedFunction == "LKrigDefaultFixedFunction"){
            cat("Fixed part of model is a polynomial of degree",
                x$LKinfo$fixedFunctionArgs$m - 1, "(m-1)", fill=TRUE)
        }  
        else{  
          cat("Fixed part of model uses the function:",
                      x$LKinfo$fixedFunction, fill = TRUE)
          cat("with the argument list:", fill = TRUE)
          print( x$LKinfo$fixedFunctionArgs)
        }
    }
    cat("Radial basis function used: ", LKinfo$basisInfo$RadialBasisFunction, 
        fill = TRUE)
    cat(" ", fill = TRUE)

      cat( LKinfo$nlevel, " Levels" , LKinfo$latticeInfo$m, "basis functions",
          "with overlap of ", 
        LKinfo$basisInfo$overlap, "(lattice units)", fill = TRUE)
    cat(" ", fill = TRUE)
#
  temp<- cbind(  1:LKinfo$nlevel, LKinfo$latticeInfo$mLevel,  LKinfo$latticeInfo$delta)
    dimnames(temp)<- list( rep("", LKinfo$nlevel), c("Level", "Lattice points", "Spacing") )
   print( temp)
    
    cat("Type of distance metric used: ", LKinfo$distance.type, 
        fill = TRUE)
#
    cat(" ", fill = TRUE)
    if (length(LKinfo$alpha[[1]]) == 1) {
        cat("Value(s) for weighting (alpha): ", unlist(LKinfo$alpha), 
            fill = TRUE)
    }
    else {
        cat("alpha values passed as a vector for each level", 
            fill = TRUE)
    }
#    
    cat(" ", fill = TRUE)
    if (length(LKinfo$a.wght[[1]]) == 1) {
        a.wght <- unlist(LKinfo$a.wght)
        cat("Value(s) for lattice dependence (a): ", a.wght, 
            fill = TRUE)
    }
    else {
        cat("Value(s) for weighting in GMRF (a.wght): ", unlist(LKinfo$alpha), 
            fill = TRUE)
    }
#    
    cat(" ", fill = TRUE)
    if (LKinfo$normalize) {
        cat("Basis functions normalized so marginal process variance is stationary", 
            fill = TRUE)
    }
  invisible(x)
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

setDefaultsLKinfo <- function(object,...){
  UseMethod("setDefaultsLKinfo")
}

# default is that no modifications are made to the LKinfo object
setDefaultsLKinfo.default <- function(object,...)
  {
    return(object)
  }
# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

surface.LKrig <- function(object, ...) {
    surface.Krig(object, ...)
}

# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

".on.Load" <- function(lib, pkg) {
    packageStartupMessage("help(LKrig) gives an overview \n\nCopyright 2011, Licensed under GPL, www.gpl.org/licenses/gpl.html ")
}
