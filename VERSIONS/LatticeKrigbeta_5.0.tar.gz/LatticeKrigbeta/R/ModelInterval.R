## LKrig model for 1-d data on an interval



LKrigSetupLattice.LKInterval <- function(object, x, verbose,
                                       NC, NC.buffer=5, grid.info=NULL, ...){
#object is usually of class LKinfo
  rangeLocations<-  range(x)
  if( ncol( x) !=1) {
       stop( "x is not 1-d !")
   }
  if( is.null( grid.info)){
    grid.info<-list( xmin=  rangeLocations[1], xmax= rangeLocations[2])
}  
  nlevel<- object$nlevel
  delta.level1<- ( grid.info$xmax - grid.info$xmin ) /( NC - 1 )
  mLevel<- rep( NA, nlevel)
  delta.save<- rep( NA, nlevel)
  grid.all.levels<- NULL
# begin multiresolution loop 
   for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width <- NC.buffer * delta
        grid.list <- list(x = seq(grid.info$xmin - buffer.width, 
            grid.info$xmax + buffer.width, delta) )
        mLevel[j] <- length(grid.list$x)
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
# end multiresolution level loop
# create a useful index that indicates where each level starts in a
# stacked vector of the basis function coefficients.
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (m - 2 * NC)
    out<-  list(  m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
  # specific arguments for LKInterval              
                  mLevelDomain = mLevelDomain,
                  NC=NC,
                  NC.buffer = NC.buffer,
                  grid = grid.all.levels)
 return( out )
}



LKrigSAR.LKInterval<- function(object, Level, ... ){
   m<- object$latticeInfo$mLevel[Level] 
   a.wght<- (object$a.wght)[[Level]]
   if( length(a.wght) > 1) {
     stop("a.wght must be constant")
   }
   da<- c( m,m)
   ra<- c(rep( a.wght, m), rep( -1, (m-1)), rep( -1, (m-1)) )
   Bi <-  c( 1:m,2:m, 1:(m-1))
   Bj<- c( 1:m, 1:(m-1), 2:m)
  return(list(ind = cbind(Bi, Bj), ra = ra, da = da)) 
}  

LKrigLatticeCenters.LKInterval<- function(object, Level, ... ){
   gridl<- object$latticeInfo$grid[[Level]]
   return( matrix( gridl$x, ncol=1) )
} 


LKrigSetupAlpha.LKInterval <- function( object, ... ){
  LKrigSetupAlpha.LKRectangle(object)
  }
  