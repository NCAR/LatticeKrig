LKrig.make.par.grid <-
function (par.grid = NULL, par.grid.matrix=NULL, LKinfo = NULL) 
{
    if( !is.null(par.grid.matrix)){
      # fill in list format from columns of matrix
       par.grid.matrix<- rbind( par.grid.matrix)
       if( is.null(LKinfo)){
         stop("need to pass LKinfo list")}
         nlevel<- LKinfo$nlevel
         N<- ncol( par.grid.matrix)
         par.grid<- list()
         if( nlevel >1){
         par.grid$gamma<- (par.grid.matrix[, 1:(nlevel-1)])
       }
       else{
         par.grid$alpha<- matrix( 1, nrow=nrow(par.grid.matrix),ncol=1)}
         Nlkappa<- (N-1) - nlevel  + 1
         par.grid$lkappa<-matrix(par.grid.matrix[, nlevel: (N-1)], ncol=Nlkappa)       
         par.grid$llambda<-(par.grid.matrix[,N])
       }     
      # fill in par.grid with everything that LKrig needs for fit covariance
      # and with the right format
      par.grid$llambda <-  as.matrix(par.grid$llambda)
# if needed create alpha       
        if (!is.null(par.grid$gamma)) {
            if( !is.matrix( par.grid$gamma)){
              par.grid$gamma<- cbind(  par.grid$gamma)}
            par.grid$alpha <- cbind(1, exp(par.grid$gamma))
            for (j in 1:nrow(par.grid$gamma)) {
                par.grid$alpha[j, ] <- par.grid$alpha[j, ]/sum(par.grid$alpha[j, ])
            }
        }
      par.grid$alpha<- as.matrix( par.grid$alpha)
# if needed create a.wght   
        nlevel <- ncol(par.grid$alpha)
        if (!is.null(par.grid$lkappa)) {
        # coerce to lkappa to a matrix  
            par.grid$lkappa<- as.matrix(par.grid$lkappa)
        # check dimensions of lkappa
            Nlkappa<- ncol( par.grid$lkappa)
            if( !(Nlkappa ==1 | Nlkappa ==nlevel) ){
              stop("lkappa has wrong dimensions")}            
            a.wght <- as.matrix(4 + 1/(exp(par.grid$lkappa)^2))                           
            par.grid$a.wght<- matrix(a.wght, ncol=nlevel, nrow= nrow(a.wght))
        }
       else{
       # add in lkappa  
          par.grid$lkappa<- as.matrix(1/sqrt(par.grid$a.wght-4))}
    # to bulletproof coerce a.wght to matrix in case it is not one
       par.grid$a.wght<- as.matrix( par.grid$a.wght)    
    
    return(par.grid)
}
