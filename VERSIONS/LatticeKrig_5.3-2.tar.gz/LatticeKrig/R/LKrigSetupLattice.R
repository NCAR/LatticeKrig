LKrigSetupLattice <- function(object, ...){
  UseMethod("LKrigSetupLattice")
}

LKrigSetupLattice.default<- function( object,...){
   stop("LKGeometry needs to be specified,  e.g. LKRectangle")
 }

