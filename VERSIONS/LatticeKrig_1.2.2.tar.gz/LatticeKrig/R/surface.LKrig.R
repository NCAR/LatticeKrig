surface.LKrig <-
function(object,...){
  surface.Krig( object,...)}

