
setClass("gridList", prototype= list( seq(0,1,,40) ) )

setMethod("summary", signature(object="gridList"),
function( object){
	gridListInfo(object)
}
)

gridListInfo<- function( gridList){
	Nl<- length (gridList)
	minOut<- maxOut<- n <- dx <-  rep( NA, Nl)
	for( k in 1:Nl){
		gridK<- gridList[[k]]
		minOut[k]<- min( gridK)
		maxOut[k]<- max( gridK)
		n[k]<- length( gridK)
		dx[k] <- gridK[2] - gridK[1]
#		if( any(diff(gridK) != dx[k])) {
#			warning("Not all grid points are equally spaced")
#		}	
	}
	return( list(dim =Nl, min= minOut, max=maxOut, n=n, dx=dx) )
}    
 