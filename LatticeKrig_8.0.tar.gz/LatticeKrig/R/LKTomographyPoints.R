LKTomographyPoints <- function(latticeInfo) {
  levelSizes <- t(latticeInfo$mxDomain)
  dimension <- as.integer(dim(levelSizes)[1])
  nLevels <- as.integer(dim(levelSizes)[2])
  nPoints <- as.integer(sum(apply(levelSizes, 2, prod)))
  levelSizes <- as.integer(levelSizes)
  points <- as.double(matrix(0, dimension * nPoints, nrow = dimension))
  coordinates <- as.double(unlist(latticeInfo$grid))
  out <- .Fortran("LKTomPoints3D", coorinates=coordinates, levelSizes=levelSizes,
                  nLevels=nLevels, points=points, nPoints=nPoints, PACKAGE="LatticeKrig")
  
  points <- matrix(out$points, nrow = dimension)
  return(points)
}