## LKrig model for 3-d data in a box
#
setDefaultsLKinfo.LKBox<- function( object, ...)
  {
    # object == LKinfo
  if( is.null(object$setArgs$NC) ){
    object$setupArgs$NC<- 5
    object$setupArgs$NC.buffer<- 2
  }
  if( is.null( object$setupArgs$a.wght) ){
      object$setupArgs$a.wght<- 6.01
    }
  return( object)
  }

LKrigSetupLattice.LKBox <- function(object, x, verbose,
                                       NC, NC.buffer=5, grid.info=NULL, ...){
#object is usually of class LKinfo
  rangeLocations<-  apply(x, 2, "range")
  if( ncol( x) !=3) {
       stop( "x is not 3-d !")
   }
  if( is.null( grid.info)){
    grid.info<-list( range= rangeLocations )
    }  
  nlevel<- object$nlevel
  delta.level1<- max(grid.info$range[2,] - grid.info$range[1,]) /( NC - 1 )
  mx<- mxDomain<- matrix( NA, ncol = 3, nrow= nlevel)
  mLevel<- rep( NA, nlevel)
  delta.save<- rep( NA, nlevel)
  grid.all.levels<- NULL
# begin multiresolution loop 
   for (j in 1:nlevel) {
        delta <- delta.level1/(2^(j - 1))
        delta.save[j] <- delta
        # the width in the spatial coordinates for NC.buffer grid points at this level.
        buffer.width <- NC.buffer * delta
  # NOTE delta distance of lattice is the same in all dimensions      
        grid.list <- list( x1= seq(grid.info$range[1,1] - buffer.width, 
                                   grid.info$range[2,1] + buffer.width, delta),
                           x2= seq(grid.info$range[1,2] - buffer.width, 
                                   grid.info$range[2,2] + buffer.width, delta),
                           x3= seq(grid.info$range[1,3] - buffer.width, 
                                   grid.info$range[2,3] + buffer.width, delta)       
                                    )
        mx[j,] <- unlist(lapply(grid.list, "length"))
        mxDomain[j,]<- mx[j,] - 2*NC.buffer
        mLevel[j]<- prod( mx[j,])
        grid.all.levels <- c(grid.all.levels, list(grid.list))
    } 
# end multiresolution level loop
# create a useful index that indicates where each level starts in a
# stacked vector of the basis function coefficients.
    offset <- as.integer(c(0, cumsum(mLevel)))
    m<- sum(mLevel)
    mLevelDomain <- (mLevel - 2 * NC.buffer)
    out<-  list(
# required arguments for latticeInfo  
      m = m, offset = offset, mLevel = mLevel,
                  delta = delta.save, rangeLocations = rangeLocations,
# specific arguments for LKBox Geometry            
                  mx = mx, mLevelDomain = mLevelDomain, mxDomain = mxDomain, 
                  NC = NC,
                  NC.buffer = NC.buffer,
                  grid = grid.all.levels)
 return( out )
}

LKinfo<- list( latticeInfo= list( mLevel=60, mx=rbind( c(4,3,5) )), a.wght= list( 6.5) ) 

LKrigSAR.LKBox<- function(object, Level,...){
   m<- object$latticeInfo$mLevel[Level] 
   a.wght<- (object$a.wght)[[Level]]
   if( length(a.wght) > 1) {
     stop("a.wght must be constant")
   }
   da<- c( m,m)
   # INTIALLY create all arrays for indices ignoring boudaries
   #  e.g. an edge really only has 2 or 3 neighbors not 4.
   ra<- c(rep( a.wght, m), rep( -1, m*6) )
   Bi <-  c( rep( 1:m,7))
   Bindex<- array( 1:m, object$latticeInfo$mx[Level,])
  # indexing is East, West, South, North, Down, Up.
   Bj<- c( 1:m, 
       c(LKArrayShift(Bindex, c(-1, 0, 0) ) ), 
       c(LKArrayShift(Bindex, c( 1, 0, 0) ) ), 
       c(LKArrayShift(Bindex, c( 0,-1, 0) ) ), 
       c(LKArrayShift(Bindex, c( 0, 1, 0) ) ),
       c(LKArrayShift(Bindex, c( 0, 0,-1) ) ), 
       c(LKArrayShift(Bindex, c( 0, 0, 1) ) )
   )  
   inRange<- !is.na( Bj)
   Bi<- Bi[inRange]
   Bj<- Bj[inRange]
     ra<- ra[inRange]
  return(list(ind = cbind(Bi, Bj), ra = ra, da = da)) 
}  

LKrigLatticeCenters.LKBox<- function(object, Level,...){
   gridl<- object$latticeInfo$grid[[Level]]
   return( as.matrix(expand.grid( gridl)) )
} 










