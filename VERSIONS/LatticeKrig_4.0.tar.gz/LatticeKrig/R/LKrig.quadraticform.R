LKrig.quadraticform <- function(Q, PHI) {
    #   finds     the quadratic forms    PHI_j^T Q.inverse PHI_j  where PHI_j is the jth row of
    #   PHI.
    #   The loop is to avoid using memory for the entire problem if more than 2000 elements.
    nrow <- dim(PHI)[1]
    choleskyPrecision<- chol(Q)
    if (nrow > 1) {
        BLOCKSIZE <- 2000
        wght <- rep(NA, nrow)
        counter <- 1
        while (counter < nrow) {
            ind <- counter:min((counter + BLOCKSIZE), nrow)
            A <- forwardsolve(l = choleskyPrecision, transpose = TRUE, 
                x = t(PHI[ind, ]), upper.tri = TRUE)
            wght[ind] <- c(colSums(A^2))
            counter <- counter + BLOCKSIZE
        }
    }
    else {
        # Unfortunately the case when there is one row needs to be handled separately.
        A <- forwardsolve(l = choleskyPrecision, transpose = TRUE,
                           x = t(PHI), upper.tri = TRUE)
        wght <- sum(A^2)
    }
    return(wght)
}
