# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu,
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKDistGrid<- function( x1, gridList, delta, max.points = NULL, 
                      mean.neighbor = NULL, distance.type="Euclidean",
                      periodic= attr(gridList,"periodic")
                      ){
         LKGridCheck( distance.type, x1, gridList) 
         n1<- nrow(x1)
         info<- summary( gridList)
# figure out how large an array to allocate for distance matrix 
         Nmax<- LKGridFindNmax(n1, max.points, mean.neighbor,delta,gridList)        
# NOTE all the dx's should be equal -- this is checked above 
# FORTRAN expects x1 to be centered and scaled to the grid. 
# i.e. the grid coordinates  are all just integer values 1:10 etc.
         xScaled <- scale( x1, center = info$min, scale = info$dx) + 1 
         deltaScaled <- delta/mean(info$dx) 
         nDim<- info$dim
         nGrid<-info$n
# if periodic pad the grid and shift the x1 locations.
     if(is.null(periodic)){
         	periodic<-rep( FALSE, nDim)
         	nGridFULL<- nGrid
         }
     else{    
        	nPad<- ifelse( periodic, ceiling( deltaScaled), 0)
            nGridFULL<- nGrid + 2 * nPad
            xScaled <- 	scale( xScaled , center = -nPad, scale=FALSE)   
    	}        
    out <- .Fortran("LKdistgrid", x1 = as.double(xScaled),
                                  n1 = as.integer(n1), 
                               nGrid = as.integer( nGridFULL),
                                nDim = as.integer(nDim), 
                               delta = as.double(deltaScaled),
                                irow = as.integer(rep(0, Nmax)),
                                jcol = as.integer(rep(0, Nmax)),       
                                  ra = as.double(rep(-1, Nmax)),
                                Nmax = as.integer(Nmax),
                               iflag = as.integer(1),
                               index = as.integer( rep(-1,Nmax*info$dim)),
                             PACKAGE = "LatticeKrig")
# out$Nmax are now the actual number of nonzero distances found. 
# unless there was an error (iflag!=0)                            
      N <- out$Nmax
      if (N==0) {
            stop("delta too small! -- no points found")
            }
      if( out$iflag <0){
      	stop( paste( "Nmax = " , N, " exceeded")  )
      } 
# if periodic fix up indices. Convert indices in the padded parts to
# indices where the grid is wrapped around. 
# e.g.     given  1: 10  where nPad is 2. The actual peridic grid is 
# 1:8  and    2 -> 8   1-> 7   9 -> 1 10 -> 2 
#         
      jcol= out$jcol        
      if( any(periodic)){
         jcol<- convertIndexPeriodic( out$jcol,nGridFULL,nPad)     
      }  
  	  out<- list(
  	             ind = cbind( out$irow[1:N], jcol[1:N] ) ,
                  ra = out$ra[1:N] * mean(info$dx),
                  da = c(n1,prod(nGrid))
                )            
#                  ,jcolFULL=out$jcol[1:N],
#                  nGridFULL=nGridFULL
# )               
      return(out)
    }
 
 LKDistGridComponents<- function( x1, gridList, delta,
                         max.points = NULL, 
                      mean.neighbor = NULL,
                      distance.type = "Euclidean"
                     ){
         LKGridCheck( distance.type, x1, gridList) 
         n1<- nrow(x1)
         info<- summary( gridList ) 
# figure out how large an array to allocate for distance matrix 
         Nmax<- LKGridFindNmax(n1, max.points, mean.neighbor,delta,gridList)        
# NOTE all the dx's should be equal -- this is checked above 
# FORTRAN expects x1 to be centered and scaled to the grid. 
# i.e. the grid coordinates  are all just integer values 1:10 etc.
         xScaled <- scale( x1, center = info$min, scale = info$dx) + 1 
         deltaScaled <- delta/mean(info$dx)    	
    out <- .Fortran("LKdistgridcomp",
                                  x1 = as.double(xScaled),
                                  n1 = as.integer(n1), 
                               nGrid = as.integer( info$n),
                                nDim = as.integer(info$dim), 
                               delta = as.double(deltaScaled),
                                irow = as.integer(rep(0, Nmax)),
                                jcol = as.integer(rep(0, Nmax)),       
                                  ra = as.double(rep(-1, Nmax*info$dim)),
                                Nmax = as.integer(Nmax),
                               iflag = as.integer(1),
                               index = as.integer( rep(-1,Nmax*info$dim)),
                             PACKAGE = "LatticeKrig")
                             
# out$Nmax are now the actual number of nonzero distances found. 
# unless there was an error (iflag!=0)                            
      N <- out$Nmax
      if (N==0) {
            stop("delta too small! -- no points found")
            }
      if( out$iflag <0){
      	stop( paste( "Nmax = " , N, " exceeded")  )
      }           
      DX<- mean(info$dx)
      raOut<- DX* matrix(out$ra,  nrow=Nmax, ncol=info$dim )[1:N,]                     
  	  out<- list(
  	             ind = cbind( out$irow[1:N], out$jcol[1:N] ) ,
                  ra = raOut,                  
                  da = c(n1,prod(out$nGrid))
                )            
               
      return(out)
    }
 

 
 
# A utility function to setup up some variables and avoid 
# dupicating code between radial and component functions 
 LKGridCheck<- function( distance.type, x1, gridList){
 	 if( distance.type!="Euclidean"){
     	stop("Only Euclidean distance supported")
   	 	}	
     if( !is.matrix( x1)){
     	stop( "x1 must be a matrix")
     }	  	 	
   	 if( class(gridList)!="gridList"){
   	 	stop("gridList must have class gridList")
   	 }
   	info<- summary( gridList)
   	if( info$dim != ncol(x1)){
   		stop("number of components in gridList and columns of x1
   		are not equal.")
   	}
# check that all the grid spacings are the same    
    Dx <- info$dx
     check<- max( abs(info$dx - mean( info$dx))/ mean( info$dx) )
    if( check> 1e-7 )  {
    	stop(paste( check, " gridList spacings must all be the same.") )
    }
 }

LKGridFindNmax<- function(n1, max.points, mean.neighbor, delta, gridList){    
# figure out how large an array to allocate for distance matrix   
#    n1 <- nrow(x1)
    info<- summary( gridList)
    deltaScaled<- delta/info$dx
# estimate upper bound for the max.points
    if( !is.null( mean.neighbor) ){
	    max.points <- mean.neighbor*n1 
	 }   
    if (is.null(max.points)) {
        max.points <- n1 * ceiling(prod(deltaScaled*2 + 1 ) )
     }
    return( max.points )
} 
 