LKrigLatticeCenters <- function( object, ...){
  UseMethod("LKrigLatticeCenters")
}

LKrigLatticeCenters.default<- function( object,...){
   stop("LKGeometry  class needs to be specified")
 }
