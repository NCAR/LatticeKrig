    



 
 
                         
setGeneric(name="LKrigDistance", function( x1, x2, delta, ...  )
 { 
 	standardGeneric("LKrigDistance")
 	}
 )
    
setMethod("LKrigDistance", 
signature(x1 = "matrix", x2 = "matrix", delta = "numeric" ),
function( x1, x2, delta, 
         max.points = NULL, mean.neighbor = 50 ,  distance.type = "Euclidean",
         components = FALSE ){    
	if( !components){
		LKDist(x1, x2, delta,
		 max.points = max.points, mean.neighbor = mean.neighbor,
		 distance.type = distance.type)
		}
	else{
		LKDistComponents(x1, x2, delta,
	     max.points = max.points, mean.neighbor = mean.neighbor,
	     distance.type = distance.type)	
		}
	}                   
# end definition of method 
 )


setMethod("LKrigDistance", 
signature(x1 = "matrix", x2 = "gridList", delta = "numeric"),
function( x1, x2, delta, 
         max.points = NULL,    mean.neighbor = 50 ,  distance.type = "Euclidean",
         components = FALSE){    
	if( !components){
		LKDistGrid(x1, x2,  delta,
		 max.points = max.points, mean.neighbor = mean.neighbor,
		 distance.type = distance.type)	
		}
	else{
		LKDistGridComponents(x1, x2, delta,
	     max.points = max.points, mean.neighbor = mean.neighbor,
	     distance.type = distance.type)	
		}
	}                   
# end definition of method 
 )

     
 