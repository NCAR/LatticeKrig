
 



  LKrigNormalizeBasisFast.LKRectangle<- function( LKinfo, Level, x, ...){
# some information about the rectangular lattice at level == Level  	
  mxLevel<- (LKinfo$latticeInfo$mx)[Level]
  myLevel<- (LKinfo$latticeInfo$my)[Level]
  gridStuff<- (LKinfo$latticeInfo$grid)[[Level]]
  xmin<- gridStuff$x[1]
  ymin<- gridStuff$y[1]
  dx<-  gridStuff$x[2]-  gridStuff$x[1]
  dy<-  gridStuff$y[2]-  gridStuff$y[1] 
  overlap<-  LKinfo$basisInfo$overlap
  setupList<- ( attr( LKinfo$a.wght,"fastNormDecomp"))[[Level]]
  # convert the locations to the integer scale of the lattice
  # at the level == Level          
  xLocation<- scale( x, center= c( xmin, ymin), scale= c( dx, dy)) + 1
  nLocation<- nrow( xLocation)
# solving linear system in based on writing as a Kronecker product
# see setup function for LKrigSetupAwght.LKrectangle to see 
# definitions of the matrices below.
  return(
         .Fortran("findNorm",
                          mx = as.integer(mxLevel),
			  my = as.integer(myLevel),
		      offset = as.double(overlap),
			  Ux = as.double(setupList$Ux),
			  Dx = as.double(setupList$Dx),
			  Uy = as.double(setupList$Uy),
			  Dy = as.double(setupList$Dy),
                   nLocation = as.integer(nLocation),
                   xLocation = as.double( xLocation),
                     weights = as.double( rep(-1,nLocation) ), 
	       	           Z = matrix(as.double(0),mxLevel,myLevel)
                  )$weights
         )
}
