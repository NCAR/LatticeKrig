# LatticeKrig  is a package for analysis of spatial data written for
# the R software environment .
# Copyright (C) 2012
# University Corporation for Atmospheric Research (UCAR)
# Contact: Douglas Nychka, nychka@ucar.edu, 
# National Center for Atmospheric Research, PO Box 3000, Boulder, CO 80307-3000
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or see http://www.r-project.org/Licenses/GPL-2

LKrig.setup <-
function(x=NULL, NC=NULL, NC.buffer=5, nlevel, grid.info=NULL,
                       lambda=NA, sigma=NA, rho=NA, 
                       alpha=NA, nu=NULL, a.wght=NA, overlap=2.5,
                       normalize=TRUE, normalize.level=NULL,
                       edge=FALSE, rho.object=NULL, RadialBasisFunction="WendlandFunction",
                       distance.type="Euclidean", V= diag( c(1,1)),
                       verbose=FALSE ){
#
# determines the multiresolution basis function indices.
#
 
# check distance choices
   if( is.na( match( distance.type, c( "Euclidean", "cylinder"))) ){
     stop("distance type is not supported (or is misspelled!).")}
#further checks for cylinder case
   if(distance.type =="cylinder"){
      if( V[1,1] != 1){
           stop("can not scale the angular coordinate (x[,1]),
                  assumed to be in degrees")}
      if( (V[2,1] !=0) | (V[1,2] !=0) ){
            stop("can have off diagonal elements in V")}
   }
#
  if( is.null(grid.info) ){
# if center grid information is missing create grid based on the locations
# find range of scaled locations
     if( is.null(x)){
         stop("need to specify x locations")}
     if( is.null(NC)){
         stop("need to specify NC for grid size")}
    range.x<- apply( as.matrix(x)%*%t( solve( V)) ,2, "range")
    if( verbose){
      cat( "ranges of transformed variables", range.x, fill=TRUE)}
    grid.info<- list( xmin= range.x[1,1], xmax= range.x[2,1],
                      ymin= range.x[1,2], ymax= range.x[2,2])
    d1<- grid.info$xmax- grid.info$xmin
    d2<- grid.info$ymax- grid.info$ymin
    grid.info$delta<-ifelse( distance.type=="cylinder", d1/(NC-1), max(c(d1,d2))/(NC-1))
    }

# check that cylinder geometry has the right delta with x i.e.divides range evenly.
  if( distance.type=="cylinder"){
      d1<- grid.info$xmax- grid.info$xmin
      NC.test<- d1/grid.info$delta
      if( round(NC.test- round(NC.test)) > 1e-8){
          stop("delta spacing in x dimension must be even for
          cylinder geometry")
        }
    }
# find the grid centers
  out.grid <-LKrig.make.centers(grid.info, nlevel, NC.buffer, distance.type) 
#
# repeat a.wght to fill out for all levels. 
  if( length(a.wght)==1){
    a.wght<- as.list( rep(a.wght[1],nlevel)) }
# coerce a.wght to  list  if it is passed as something else (most likely a vector)
  if( !is.list(a.wght)){
    a.wght<- as.list(a.wght)}
# some checks on a.wght
  a.wght.test<- unlist( a.wght)
  if( any( !is.na(a.wght.test)) ){
     if( any( a.wght.test<4)){              
         stop("a.wght must be >=4 if specified")}
     if( any(a.wght.test==4)&normalize){
         stop("normalize must be FALSE if a.wght ==4")}
  }
  if( !is.null(nu)){
    alpha<- exp( -(1:nlevel)*nu)
    alpha<- alpha/sum( alpha)
  }
# coerce alpha to a list if it is passed as something else
  if( !is.list( alpha)){
    alpha<- as.list( alpha)}
    scalar.alpha <- length(unlist(alpha)) == length( alpha)
# Check some details about scaling the basis functions and how they are
# normalized
  scale.basis<- !is.null(rho.object)
  if( scale.basis & !normalize){
    stop("Can not scale an unnormalized basis")}
  if( is.null(normalize.level)){
     normalize.level= rep( normalize, nlevel)}
# set lambda if sigma and rho are passed. 
  if(is.na(lambda[1])){
    lambda<- sigma^2/ rho}
# 
  out<- list(nlevel=nlevel,grid.info= grid.info,NC=NC, NC.buffer=NC.buffer,
                 delta= out.grid$delta.save, mx=out.grid$mx, my=out.grid$my,m= out.grid$m,
                 m.domain=out.grid$m.domain,
                 NC.buffer.x=out.grid$NC.buffer.x, NC.buffer.y=out.grid$NC.buffer.y,
                 offset=out.grid$offset, grid= out.grid$grid,
                 overlap=overlap, alpha=alpha, nu=nu, a.wght=a.wght,
                 lambda= lambda, sigma=sigma, rho=rho,
                 normalize=normalize,normalize.level=normalize.level, edge=edge,
                 scalar.alpha=scalar.alpha,
                 scale.basis=scale.basis, rho.object=rho.object,
                 RadialBasisFunction=RadialBasisFunction,
                 distance.type= distance.type, V=V)
  class(out)<-"LKinfo"
  return( out)
}

