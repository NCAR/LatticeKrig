LKrigLatticeCenters <- function( object, ...){
  UseMethod("LKrigLatticeCenters")
}

LKrigLatticeCenters.default<- function( object,...){
   stop("LKgeometry  class needs to be specified")
 }

LKrigLatticeCenters.LKRectangle <- function( object, Level, ...){
     grid.list <- object$latticeInfo$grid[[ Level ]]
     centers   <- make.surface.grid( grid.list)
     return( centers)
}
